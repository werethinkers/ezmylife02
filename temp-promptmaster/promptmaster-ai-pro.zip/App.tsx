
import React, { useState, useMemo, useCallback, useRef, useEffect } from 'react';
import * as LucideIcons from 'lucide-react';
import { GoogleGenAI } from "@google/genai";
import { 
  SelectionState, 
  AIModelTarget, 
  OutputFormat,
  Variation,
  CustomTag,
  WritingSkill
} from './types';
import { 
  CATEGORIES, 
  OPTIONS,
  FORMATS,
  WRITING_SKILLS,
  SHORTCUT_SHEET_CSV_URL
} from './constants';
import { buildPrompt, formatOutput } from './services/promptService';
import { suggestSimilarPrompts, magicWrite } from './services/geminiService';

const Icon = ({ name, className, size = 18, strokeWidth }: { name: string; className?: string; size?: number; strokeWidth?: number }) => {
  const LucideIcon = (LucideIcons as any)[name];
  return LucideIcon ? <LucideIcon className={className} size={size} strokeWidth={strokeWidth} /> : <LucideIcons.HelpCircle className={className} size={size} strokeWidth={strokeWidth} />;
};

const IMAGE_REF_MODES = [
  { id: 'cref', label: 'Character', param: '--cref', color: 'bg-blue-500' },
  { id: 'sref', label: 'Style', param: '--sref', color: 'bg-purple-500' },
  { id: 'img', label: 'Image', param: '', color: 'bg-emerald-500' },
  { id: 'tile', label: 'Tile', param: '--tile', color: 'bg-orange-500' },
];

const App: React.FC = () => {
  // 'text' is the first format in constants.tsx
  const [activeFormat, setActiveFormat] = useState(FORMATS[0].id);
  const [context, setContext] = useState('');
  const [negativeInput, setNegativeInput] = useState('');
  const [selections, setSelections] = useState<SelectionState>({ format: [FORMATS[0].id] });
  const [writingSkill, setWritingSkill] = useState<WritingSkill>('none');
  const [branding, setBranding] = useState({ logo: '', text: '' });
  const [customTags, setCustomTags] = useState<CustomTag[]>([]);
  const [newCustomTag, setNewCustomTag] = useState('');
  
  const [activeCategory, setActiveCategory] = useState(CATEGORIES[0].id);
  const [suggestions, setSuggestions] = useState<Variation[]>([]);
  const [isSuggesting, setIsSuggesting] = useState(false);
  const [isMagicWriting, setIsMagicWriting] = useState(false);
  const [showCopyToast, setShowCopyToast] = useState(false);
  const [showPromptPreview, setShowPromptPreview] = useState(false);
  const [isLibraryVisible, setIsLibraryVisible] = useState(true);
  const [isSkillsMenuOpen, setIsSkillsMenuOpen] = useState(false);
  
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [imageDetails, setImageDetails] = useState<string>('');
  const [audioAdopt, setAudioAdopt] = useState<string>('');
  const [isAnalyzingImage, setIsAnalyzingImage] = useState(false);
  const [imageRefModeIndex, setImageRefModeIndex] = useState(0);

  const [editableFinalPrompt, setEditableFinalPrompt] = useState('');
  const [shortcuts, setShortcuts] = useState<Map<string, string>>(new Map());

  const fileInputRef = useRef<HTMLInputElement>(null);
  const skillsRef = useRef<HTMLDivElement>(null);
  const model = AIModelTarget.MIDJOURNEY;

  useEffect(() => {
    const fetchShortcuts = async () => {
      try {
        const response = await fetch(SHORTCUT_SHEET_CSV_URL);
        const text = await response.text();
        const lines = text.split('\n');
        const map = new Map<string, string>();
        lines.forEach(line => {
          const [key, ...valueParts] = line.split(',');
          if (key && valueParts.length > 0) {
            map.set(key.trim().toLowerCase(), valueParts.join(',').trim());
          }
        });
        setShortcuts(map);
      } catch (err) {
        console.warn("Failed to fetch shortcuts:", err);
      }
    };
    fetchShortcuts();
  }, []);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (skillsRef.current && !skillsRef.current.contains(event.target as Node)) {
        setIsSkillsMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const visibleCategories = useMemo(() => {
    return CATEGORIES.filter(c => c.formats.includes(activeFormat));
  }, [activeFormat]);

  const currentRefMode = useMemo(() => IMAGE_REF_MODES[imageRefModeIndex], [imageRefModeIndex]);

  const totalContext = useMemo(() => {
    const parts = [];
    if (imageDetails) parts.push(`${currentRefMode.param} ${imageDetails}`.trim());
    if (context) parts.push(context);
    if (audioAdopt) parts.push(`Atmosphere: ${audioAdopt}`);
    return parts.join(', ');
  }, [context, imageDetails, audioAdopt, currentRefMode]);

  const promptData = useMemo(() => 
    buildPrompt(totalContext, selections, model, customTags, branding, writingSkill), 
    [totalContext, selections, model, customTags, branding, writingSkill]
  );
  
  const promptParts = useMemo(() => {
    const parts: { label: string; value: string; color: string; textColor: string; id: string; catId: string; icon?: string }[] = [];
    const fmt = FORMATS.find(f => f.id === activeFormat);
    if (fmt) {
      parts.push({ id: 'format', label: 'Format', value: fmt.label, color: fmt.color, textColor: 'text-white', catId: 'format', icon: fmt.icon });
    }
    if (imageDetails) {
      parts.push({ id: 'vision', label: currentRefMode.label, value: 'Vision Core', color: 'bg-emerald-500', textColor: 'text-white', catId: 'vision', icon: 'Scan' });
    }
    visibleCategories.forEach(cat => {
      const selectedIds = selections[cat.id] || [];
      selectedIds.forEach(id => {
        let opt: any = OPTIONS.find(o => o.id === id);
        if (!opt && cat.id === 'custom') opt = customTags.find(t => t.id === id);
        if (opt) {
          parts.push({ id: opt.id, label: cat.label, value: opt.label || opt.value, color: cat.color, textColor: 'text-white', catId: cat.id, icon: opt.iconName });
        }
      });
    });
    return parts;
  }, [selections, customTags, imageDetails, activeFormat, visibleCategories, currentRefMode]);

  const baseFormattedPrompt = useMemo(() => formatOutput(promptData, OutputFormat.PLAIN_TEXT, model), [promptData, model]);
  
  // Calculate final computed string, including MIDJOURNEY-style suffixes ONLY if not in TEXT mode
  const finalStringComputed = useMemo(() => {
    if (activeFormat === 'text') return baseFormattedPrompt;
    const negPart = promptData.negative ? ` --no ${promptData.negative}` : '';
    const extraNeg = negativeInput ? `, ${negativeInput}` : '';
    return `${baseFormattedPrompt}${negPart}${extraNeg}`;
  }, [baseFormattedPrompt, promptData.negative, negativeInput, activeFormat]);

  useEffect(() => {
    if (showPromptPreview) {
      setEditableFinalPrompt(finalStringComputed);
    }
  }, [showPromptPreview, finalStringComputed]);

  const toggleSelection = useCallback((category: string, optionId: string) => {
    setSelections(prev => {
      const current = prev[category] || [];
      const updated = current.includes(optionId) ? current.filter(id => id !== optionId) : [...current, optionId];
      return { ...prev, [category]: updated };
    });
  }, []);

  const handleFormatChange = (id: string) => {
    setActiveFormat(id);
    setSelections(prev => ({ ...prev, format: [id] }));
    const newVisible = CATEGORIES.filter(c => c.formats.includes(id));
    if (!newVisible.some(c => c.id === activeCategory)) {
      setActiveCategory(newVisible[0]?.id || 'custom');
    }
  };

  const handleCopy = () => {
    const stringToCopy = showPromptPreview ? editableFinalPrompt : finalStringComputed;
    navigator.clipboard.writeText(stringToCopy);
    setShowCopyToast(true);
    setTimeout(() => setShowCopyToast(false), 2000);
  };

  const handleBrainstorm = async () => {
    if (!totalContext.trim() && Object.keys(selections).length <= 1) return;
    setIsSuggesting(true);
    const flatSelections = Object.values(selections).flat() as string[];
    const res = await suggestSimilarPrompts(totalContext || "Modern professional communication", flatSelections, activeFormat);
    setSuggestions(res);
    setIsSuggesting(false);
  };

  const handleMagicWrite = async () => {
    if (!context.trim()) return;
    setIsMagicWriting(true);
    const res = await magicWrite(context, activeFormat);
    setSuggestions(res);
    setIsMagicWriting(false);
  };

  const analyzeImage = async (base64Data: string) => {
    setIsAnalyzingImage(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: { parts: [
          { text: "STRICT OUTPUT RULE: Return ONLY keywords. NO introductory phrases. Format: [Visual Keywords] | [Audio Keywords]. No sentences. Raw data only." },
          { inlineData: { mimeType: "image/jpeg", data: base64Data } }
        ]}
      });
      let text = response.text?.trim() || '';
      const parts = text.split('|');
      const visual = parts[0]?.trim().replace(/^(Here is|Description:)/i, '') || '';
      const audio = parts[1]?.trim() || '';
      setImageDetails(visual);
      setAudioAdopt(audio);
    } catch (err) { console.error(err); } finally { setIsAnalyzingImage(false); }
  };

  const handleAddCustomTag = () => {
    if (!newCustomTag.trim()) return;
    const tag: CustomTag = { id: `custom-${Date.now()}`, label: newCustomTag, value: newCustomTag, category: 'custom' };
    setCustomTags(prev => [...prev, tag]);
    toggleSelection('custom', tag.id);
    setNewCustomTag('');
  };

  const handleContextChange = (val: string) => {
    const words = val.split(' ');
    const lastWord = words[words.length - 1]?.toLowerCase();
    if (shortcuts.has(lastWord)) {
      const replacement = shortcuts.get(lastWord)!;
      words[words.length - 1] = replacement;
      setContext(words.join(' '));
    } else {
      setContext(val);
    }
  };

  const cycleImageRefMode = (e: React.MouseEvent) => {
    e.stopPropagation();
    setImageRefModeIndex((prev) => (prev + 1) % IMAGE_REF_MODES.length);
  };

  const cycleFormat = (e: React.MouseEvent) => {
    e.stopPropagation();
    const currentIndex = FORMATS.findIndex(f => f.id === activeFormat);
    const nextIndex = (currentIndex + 1) % FORMATS.length;
    handleFormatChange(FORMATS[nextIndex].id);
  };

  const clearContext = () => {
    setContext('');
    setSuggestions([]); // Clear suggested options when prompt is deleted
  };

  const currentCategoryObj = useMemo(() => CATEGORIES.find(c => c.id === activeCategory), [activeCategory]);
  const activeOptions = useMemo(() => activeCategory === 'custom' ? customTags : OPTIONS.filter(o => o.category === activeCategory), [activeCategory, customTags]);

  return (
    <div className="fixed inset-0 bg-[#F2F4F7] text-slate-900 flex flex-col font-sans select-none overflow-hidden h-screen">
      {/* HEADER */}
      <div className="h-14 px-4 md:px-6 flex items-center justify-between bg-white border-b border-slate-200 z-50 shadow-sm shrink-0">
        <div className="flex items-center gap-4">
          <div className="w-8 h-8 md:w-9 md:h-9 bg-slate-950 rounded-[12px] md:rounded-[14px] flex items-center justify-center text-white font-black italic shadow-xl">P</div>
          <div className="hidden sm:block">
            <h1 className="font-extrabold text-[12px] uppercase tracking-tighter text-slate-900 leading-none">PromptMaster Elite</h1>
            <p className="text-[7px] font-black text-slate-400 tracking-[0.4em] mt-1">V16.5 TEXT ENGINE</p>
          </div>
        </div>
        <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-2xl border border-slate-200 overflow-x-auto no-scrollbar max-w-[40%] sm:max-w-none">
          {FORMATS.map(f => (
            <button 
              key={f.id}
              onClick={() => handleFormatChange(f.id)}
              className={`flex items-center gap-1.5 px-2 py-1 md:px-3 md:py-1.5 rounded-xl text-[9px] md:text-[10px] font-black transition-all shrink-0 ${activeFormat === f.id ? `${f.color} text-white shadow-md` : 'text-slate-500 hover:text-slate-700'}`}
            >
              <Icon name={f.icon} size={11} />
              <span className="hidden xs:inline uppercase">{f.label}</span>
            </button>
          ))}
        </div>
        <div className="flex items-center gap-1 md:gap-2">
          <button onClick={handleBrainstorm} disabled={isSuggesting} className="p-2 hover:bg-amber-100 rounded-xl text-black transition-all" title="Brainstorm Variations"><Icon name="Sparkles" size={16} strokeWidth={2.5} className={isSuggesting ? "animate-pulse" : ""} /></button>
          <button onClick={handleCopy} className="px-3 py-2 md:px-5 md:py-2.5 bg-slate-950 text-white rounded-xl shadow-lg active:scale-95 transition-all flex items-center gap-2">
            <Icon name="Zap" size={14} />
            <span className="text-[9px] font-black uppercase tracking-widest hidden md:inline">Build & Copy</span>
          </button>
        </div>
      </div>

      <input type="file" accept="image/*" className="hidden" ref={fileInputRef} onChange={(e) => {
        const file = e.target.files?.[0];
        if (file) {
          const reader = new FileReader();
          reader.onloadend = () => {
            const base64 = reader.result as string;
            setImagePreview(base64);
            analyzeImage(base64.split(',')[1]);
          };
          reader.readAsDataURL(file);
        }
      }} />

      {/* MAIN VIEWPORT */}
      <div className="flex-1 flex overflow-hidden">
        {/* SIDE RAIL */}
        <div className="w-14 md:w-20 bg-white border-r border-slate-200 flex flex-col items-center py-6 gap-6 md:gap-8 z-40 overflow-y-auto no-scrollbar shadow-[2px_0_10px_rgba(0,0,0,0.02)] shrink-0">
          {visibleCategories.map(cat => (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id)}
              className={`flex flex-col items-center gap-1.5 group transition-all shrink-0 ${activeCategory === cat.id ? 'opacity-100 scale-110' : 'opacity-60 hover:opacity-100'}`}
            >
              <div className={`w-9 h-9 md:w-11 md:h-11 rounded-[14px] md:rounded-[16px] flex items-center justify-center transition-all ${activeCategory === cat.id ? `${cat.color} text-white shadow-xl` : 'bg-slate-100 text-black hover:bg-slate-200'}`}>
                <Icon name={cat.icon} size={18} strokeWidth={2.5} />
              </div>
              <span className={`text-[6px] md:text-[8px] font-black uppercase tracking-widest text-center max-w-full truncate ${activeCategory === cat.id ? cat.textColor : 'text-black'}`}>
                {cat.label}
              </span>
            </button>
          ))}
        </div>

        {/* WORKSPACE AREA */}
        <div className="flex-1 flex flex-col min-w-0 bg-[#F8F9FB] relative overflow-hidden">
          
          {/* SUB-CATEGORY LIBRARY */}
          <div className="bg-white border-b border-slate-200 shrink-0 z-40 shadow-sm overflow-hidden transition-all duration-300 ease-in-out">
             <div className="flex items-center justify-between px-4 py-2 bg-slate-50/50">
                <div className="flex items-center gap-2">
                   <button 
                    onClick={() => setIsLibraryVisible(!isLibraryVisible)}
                    className="p-1 hover:bg-slate-200 rounded-lg transition-colors text-black"
                    title={isLibraryVisible ? "Hide Library" : "Show Library"}
                   >
                     <Icon name={isLibraryVisible ? "ChevronUp" : "ChevronDown"} size={14} strokeWidth={3} />
                   </button>
                   <span className="text-[8px] font-black text-black uppercase tracking-[0.3em]">{activeCategory} Library</span>
                </div>
                {activeCategory === 'custom' && isLibraryVisible && (
                  <div className="flex items-center gap-2">
                    <input type="text" className="bg-white border border-slate-200 py-1 px-3 text-[8px] font-black rounded-lg w-32 focus:outline-none uppercase text-black" placeholder="Add custom..." value={newCustomTag} onChange={(e) => setNewCustomTag(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && handleAddCustomTag()} />
                  </div>
                )}
             </div>
             
             {isLibraryVisible && (
               <div className="flex items-center gap-4 px-4 h-16 md:h-20 overflow-x-auto no-scrollbar snap-x animate-in slide-in-from-top-2 duration-300">
                  {activeOptions.map(opt => {
                    const isSelected = selections[activeCategory]?.includes(opt.id);
                    const isDisabled = opt.onlyForFormats && !opt.onlyForFormats.includes(activeFormat);
                    if (isDisabled) return null;
                    return (
                      <button key={opt.id} onClick={() => toggleSelection(activeCategory, opt.id)} className={`flex flex-col items-center gap-1 group transition-all shrink-0 pb-1 snap-center ${isSelected ? 'opacity-100' : 'opacity-60 hover:opacity-100'}`}>
                        <div className={`w-8 h-8 md:w-10 md:h-10 rounded-[12px] md:rounded-[14px] flex items-center justify-center transition-all relative ${isSelected ? `${currentCategoryObj?.color} text-white shadow-xl scale-110` : 'bg-slate-100 text-black hover:bg-slate-200'}`}>
                          <Icon name={opt.iconName || 'Box'} size={16} strokeWidth={2.5} />
                          {isSelected && <div className="absolute -top-1 -right-1 w-3.5 h-3.5 bg-white rounded-full flex items-center justify-center shadow-md border-2 border-slate-900"><Icon name="Check" className="text-slate-950" size={6} strokeWidth={5} /></div>}
                        </div>
                        <span className={`text-[7px] font-black uppercase tracking-widest text-center max-w-[56px] truncate text-black font-bold`}>{opt.label}</span>
                      </button>
                    );
                  })}
               </div>
             )}
          </div>

          {/* ASSEMBLY BAR & INPUTS */}
          <div className="p-3 md:p-6 border-b border-slate-200 bg-white/50 backdrop-blur-xl shrink-0">
            <div className="max-w-6xl mx-auto space-y-3 md:space-y-4">
              <div className="bg-white border border-slate-200 rounded-[22px] md:rounded-[28px] p-2 pr-4 shadow-sm flex items-center gap-2 md:gap-3 relative overflow-hidden group">
                <div className="flex flex-wrap items-center gap-1.5 md:gap-2 flex-1 pl-1 md:pl-2 overflow-x-auto no-scrollbar">
                  <button onClick={() => fileInputRef.current?.click()} className="w-7 h-7 md:w-8 md:h-8 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center hover:bg-emerald-600 hover:text-white transition-all shadow-sm border border-emerald-100 shrink-0" title="Add Image Reference">
                    <Icon name="Plus" size={14} strokeWidth={3} />
                  </button>
                  <div className="h-5 w-px bg-slate-200 mx-0.5 shrink-0"></div>
                  {promptParts.length > 0 ? (
                    promptParts.map((p, i) => (
                      <span key={i} 
                        onClick={(e) => { 
                          e.stopPropagation(); 
                          if(p.catId === 'format') cycleFormat(e); 
                          else if(p.catId !== 'vision') setActiveCategory(p.catId); 
                        }}
                        className={`px-2 py-1 md:px-3 md:py-1.5 rounded-lg md:rounded-xl text-[8px] md:text-[9px] font-bold shadow-sm flex items-center gap-1.5 transition-all hover:scale-105 active:scale-95 ${p.color} ${p.textColor} uppercase tracking-tight border border-white/10 shrink-0 cursor-pointer`}
                        title={p.catId === 'format' ? "Click to cycle format" : `Category: ${p.label}`}
                      >
                        {p.icon && <Icon name={p.icon} size={9} />}
                        {p.value}
                      </span>
                    ))
                  ) : (
                    <span className="text-slate-400 text-[9px] md:text-[10px] font-black uppercase tracking-[0.2em] px-2 italic">Assemble modular components...</span>
                  )}
                </div>
                {imagePreview && (
                  <button 
                    onClick={cycleImageRefMode}
                    className="w-10 h-10 md:w-12 md:h-12 rounded-lg md:rounded-xl border-2 border-emerald-500 shadow-lg overflow-hidden flex-shrink-0 hover:scale-105 active:scale-95 transition-transform relative group/img cursor-pointer"
                    title={`Mode: ${currentRefMode.label}. Click to cycle modes.`}
                  >
                    <img src={imagePreview} className="w-full h-full object-cover" alt="ref" />
                    <div className="absolute top-0 right-0 left-0 bg-black/60 text-[6px] font-black text-white uppercase text-center py-0.5 tracking-tighter">
                      {currentRefMode.id}
                    </div>
                    <div className="absolute inset-0 bg-black/40 opacity-0 group-hover/img:opacity-100 transition-opacity flex items-center justify-center">
                      <Icon name="RefreshCw" size={12} className="text-white animate-spin-slow" />
                    </div>
                  </button>
                )}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-1 gap-2 md:gap-3">
                 <div className="relative group flex flex-col">
                    <Icon name="Search" size={12} className="absolute left-4 top-5 text-black group-focus-within:text-indigo-600 z-10" />
                    <textarea 
                      className="w-full bg-white border border-slate-200 py-3.5 px-10 text-[10px] md:text-xs font-bold text-black placeholder-slate-400 focus:outline-none focus:border-indigo-400 rounded-xl md:rounded-2xl shadow-sm uppercase resize-none leading-relaxed"
                      placeholder={activeFormat === 'text' ? "Type your message or draft here..." : "Context / Keywords (e.g. Cyber City)..."}
                      rows={8}
                      value={context} 
                      onChange={(e) => handleContextChange(e.target.value)} 
                    />
                    
                    <div className="absolute right-4 bottom-3 flex items-center gap-2 z-20">
                      {/* Clear Button */}
                      <button 
                        onClick={clearContext}
                        className="w-9 h-9 md:w-10 md:h-10 flex items-center justify-center rounded-xl transition-all shadow-md border bg-slate-50 text-slate-400 border-slate-200 hover:bg-rose-50 hover:text-rose-500 hover:border-rose-100 active:scale-90"
                        title="Clear All Context"
                      >
                        <Icon name="Trash2" size={14} strokeWidth={2.5} />
                      </button>

                      {/* View Button */}
                      <button 
                        onClick={() => setShowPromptPreview(true)}
                        className="w-9 h-9 md:w-10 md:h-10 flex items-center justify-center rounded-xl transition-all shadow-md border bg-slate-50 text-black border-slate-200 hover:bg-slate-100 active:scale-90"
                        title="View Final Engineered Text"
                      >
                        <Icon name="Eye" size={14} strokeWidth={2.5} />
                      </button>

                      {/* Style Button */}
                      <div className="relative" ref={skillsRef}>
                        <button 
                          onClick={() => setIsSkillsMenuOpen(!isSkillsMenuOpen)}
                          className={`w-9 h-9 md:w-10 md:h-10 flex items-center justify-center rounded-xl transition-all shadow-md border ${writingSkill !== 'none' ? 'bg-indigo-600 text-white border-indigo-500' : 'bg-slate-50 text-black border-slate-200 hover:bg-slate-100'} active:scale-90`}
                          title={`Writing Style: ${WRITING_SKILLS.find(s => s.id === writingSkill)?.label}`}
                        >
                          <Icon name="PenTool" size={14} strokeWidth={2.5} />
                        </button>
                        
                        {isSkillsMenuOpen && (
                          <div className="absolute right-0 bottom-full mb-2 bg-white border border-slate-200 rounded-xl shadow-2xl p-2 z-[100] w-48 animate-in slide-in-from-bottom-2 duration-200">
                            {WRITING_SKILLS.map(skill => (
                              <button
                                key={skill.id}
                                onClick={() => { setWritingSkill(skill.id); setIsSkillsMenuOpen(false); }}
                                className={`w-full text-left px-3 py-2 rounded-lg text-[10px] font-bold uppercase transition-all ${writingSkill === skill.id ? 'bg-indigo-50 text-indigo-600' : 'text-slate-600 hover:bg-slate-50'}`}
                              >
                                {skill.label}
                              </button>
                            ))}
                          </div>
                        )}
                      </div>

                      {/* Magic Button */}
                      <button
                        onClick={handleMagicWrite}
                        disabled={isMagicWriting || !context.trim()}
                        className="w-9 h-9 md:w-10 md:h-10 flex items-center justify-center bg-slate-950 text-white rounded-xl hover:scale-105 active:scale-95 transition-all shadow-lg disabled:opacity-30"
                        title="Magic AI Refinement"
                      >
                        <Icon name="Wand2" size={14} strokeWidth={2.5} className={isMagicWriting ? 'animate-pulse' : ''} />
                      </button>
                    </div>
                 </div>

                 {activeFormat !== 'text' && (
                   <div className="relative group animate-in slide-in-from-bottom-1 duration-200">
                      <Icon name="ShieldAlert" size={12} className="absolute left-4 top-1/2 -translate-y-1/2 text-black group-focus-within:text-rose-600" />
                      <input 
                        type="text" 
                        className="w-full bg-white border border-slate-200 py-2.5 px-10 text-[9px] md:text-[10px] font-bold text-rose-600 placeholder-rose-200 focus:outline-none focus:border-rose-400 rounded-xl md:rounded-2xl shadow-sm uppercase"
                        placeholder="Negative (e.g. Blurry, Distorted)..." 
                        value={negativeInput} 
                        onChange={(e) => setNegativeInput(e.target.value)} 
                      />
                   </div>
                 )}
              </div>
            </div>
          </div>

          <div className="flex-1 overflow-y-auto no-scrollbar p-4 md:p-6 pb-20">
            <div className="max-w-6xl mx-auto space-y-10">
              {suggestions.length > 0 && (
                <div className="space-y-4 animate-subtle">
                   <div className="flex items-center gap-2 border-l-4 border-black pl-4">
                      <h4 className="text-[10px] font-black text-black uppercase tracking-widest">
                        {activeFormat === 'text' ? 'Message Variations & Refinements' : 'AI Variations & Insights'}
                      </h4>
                   </div>
                   <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 md:gap-4">
                      {suggestions.map((s, idx) => (
                        <div key={idx} className="bg-white border border-slate-200 rounded-[22px] p-5 shadow-sm hover:border-black transition-all group cursor-pointer" onClick={() => {setContext(s.prompt); setShowPromptPreview(true);}}>
                           <div className="flex items-center justify-between mb-3">
                              <span className="text-[9px] font-black text-black uppercase tracking-widest">{s.title}</span>
                              <Icon name="ChevronRight" size={12} className="text-black group-hover:text-indigo-500 transition-colors" />
                           </div>
                           <p className="text-[10px] font-bold text-slate-700 leading-relaxed line-clamp-3">"{s.prompt}"</p>
                        </div>
                      ))}
                   </div>
                </div>
              )}

              {(imageDetails || audioAdopt) && (
                <div className="p-6 md:p-8 bg-emerald-50 rounded-[32px] md:rounded-[36px] border border-emerald-100 animate-subtle flex flex-col md:flex-row gap-6 md:gap-8 items-center md:items-start group shadow-inner">
                   <div className="w-14 h-14 md:w-16 md:h-16 bg-emerald-600 rounded-[20px] md:rounded-[22px] flex items-center justify-center text-white flex-shrink-0 shadow-2xl transition-transform group-hover:scale-110">
                     <Icon name="Scan" size={24} />
                   </div>
                   <div className="flex-1 text-center md:text-left space-y-4 md:space-y-6">
                      <div>
                        <div className="flex items-center justify-center md:justify-start gap-3 mb-2">
                          <h4 className="text-[9px] md:text-[10px] font-black text-emerald-800 uppercase tracking-[0.2em]">Vision Core Analysis</h4>
                          <span className={`px-2 py-0.5 ${currentRefMode.color} text-white text-[7px] font-black rounded uppercase ml-2 shadow-sm`}>{currentRefMode.label} Reference</span>
                        </div>
                        <p className="text-[10px] md:text-xs font-black text-emerald-900/60 leading-relaxed italic uppercase">"{imageDetails}"</p>
                      </div>
                      <div className="mt-4 flex flex-wrap justify-center md:justify-start gap-3">
                        <button onClick={() => {setContext(prev => prev ? prev + ', ' + imageDetails : imageDetails); setImageDetails('');}} className="px-5 py-2.5 bg-emerald-600 text-white rounded-xl text-[9px] font-black uppercase tracking-widest shadow-lg active:scale-95 transition-all">Merge vision core</button>
                        <button onClick={() => { setImageDetails(''); setAudioAdopt(''); setImagePreview(null); }} className="px-4 py-2.5 bg-white text-emerald-600 border border-emerald-100 rounded-xl text-[9px] font-black uppercase tracking-widest active:scale-95 transition-all">Discard</button>
                      </div>
                   </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {showPromptPreview && (
        <div className="fixed inset-0 z-[120] bg-slate-950/40 backdrop-blur-sm flex items-center justify-center p-4 md:p-6 animate-in fade-in duration-300">
           <div className="bg-white w-full max-w-2xl rounded-[32px] md:rounded-[40px] shadow-2xl overflow-hidden animate-in zoom-in-95">
              <div className="px-6 py-4 md:px-8 md:py-6 flex items-center justify-between border-b border-slate-100">
                 <div className="flex items-center gap-3">
                   <div className="w-8 h-8 md:w-10 md:h-10 bg-slate-900 rounded-xl md:rounded-2xl flex items-center justify-center text-white"><Icon name="Terminal" size={18} /></div>
                   <div><h3 className="text-sm md:text-base font-black text-slate-900 uppercase">Engineered Terminal</h3></div>
                 </div>
                 <button onClick={() => setShowPromptPreview(false)} className="p-2 bg-slate-50 rounded-xl hover:bg-slate-100 active:scale-90 transition-all"><Icon name="X" size={18} /></button>
              </div>
              <div className="p-6 md:p-8">
                 <div className="bg-slate-50 rounded-[20px] p-6 border border-slate-200 shadow-inner group relative">
                    <textarea 
                      className="w-full h-48 md:h-64 bg-transparent text-xs md:text-sm font-medium text-slate-700 leading-relaxed break-words font-mono focus:outline-none resize-none"
                      value={editableFinalPrompt}
                      onChange={(e) => setEditableFinalPrompt(e.target.value)}
                    />
                    <div className="absolute top-2 right-2 text-[8px] font-black text-slate-300 uppercase tracking-widest pointer-events-none">Editable String</div>
                 </div>
              </div>
              <div className="px-6 py-4 md:px-8 md:py-6 bg-slate-50 border-t border-slate-100 flex justify-end gap-3">
                 <button onClick={handleCopy} className="px-6 py-3 md:px-8 md:py-4 bg-slate-950 text-white rounded-xl md:rounded-2xl text-[10px] font-black uppercase tracking-widest shadow-xl flex items-center gap-2 hover:scale-105 active:scale-95 transition-all">
                    <Icon name="Zap" size={14} /> Copy Final String
                 </button>
              </div>
           </div>
        </div>
      )}

      {showCopyToast && (
        <div className="fixed top-20 left-1/2 -translate-x-1/2 z-[110] bg-slate-950 text-white px-6 py-3 rounded-full shadow-2xl flex items-center gap-3 animate-subtle border border-white/10">
          <div className="w-5 h-5 bg-emerald-500 rounded-full flex items-center justify-center"><Icon name="Check" className="text-white" size={12} /></div>
          <span className="text-[10px] font-black uppercase tracking-widest text-center">Prompt Copied</span>
        </div>
      )}

      {isAnalyzingImage && (
        <div className="fixed inset-0 bg-white/95 backdrop-blur-2xl z-[110] flex flex-col items-center justify-center">
          <div className="w-16 h-16 md:w-20 md:h-20 relative mb-8">
            <div className="absolute inset-0 border-[6px] md:border-[8px] border-slate-100 rounded-[30px] md:rounded-[36px]"></div>
            <div className="absolute inset-0 border-[6px] md:border-[8px] border-emerald-600 rounded-[30px] md:rounded-[36px] border-t-transparent animate-spin"></div>
          </div>
          <p className="text-lg md:text-xl font-black text-emerald-600 tracking-[0.6em] uppercase animate-pulse">Scanning Core</p>
        </div>
      )}
    </div>
  );
};

export default App;
