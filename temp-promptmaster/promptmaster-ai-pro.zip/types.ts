
export enum AIModelTarget {
  MIDJOURNEY = 'Midjourney',
  STABLE_DIFFUSION = 'Stable Diffusion',
  DALLE = 'DALL·E 3',
  CHATGPT = 'ChatGPT / Claude'
}

export enum OutputFormat {
  PLAIN_TEXT = 'Plain Text',
  STRUCTURED = 'Structured',
  MIDJOURNEY_SYNTAX = 'MJ Syntax',
  JSON = 'JSON'
}

export type WritingSkill = 'none' | 'rewrite' | 'professional' | 'personal' | 'friendly' | 'informative' | 'creative';

export interface PromptOption {
  id: string;
  label: string;
  value: string;
  category: string;
  iconName?: string;
  positiveTokens?: string[];
  negativeTokens?: string[];
  onlyForFormats?: string[];
}

export interface PromptState {
  primary: string;
  positive: string;
  negative: string;
  outputType: string;
  writingSkill: WritingSkill;
  branding: {
    logo?: string;
    text?: string;
  };
}

export interface CustomTag {
  id: string;
  label: string;
  value: string;
  category: string;
}

export interface SelectionState {
  [category: string]: string[];
}

export interface Variation {
  title: string;
  prompt: string;
}
