
import React from 'react';

interface ChipProps {
  label: string;
  isSelected: boolean;
  onClick: () => void;
  type?: 'primary' | 'secondary';
}

const Chip: React.FC<ChipProps> = ({ label, isSelected, onClick, type = 'primary' }) => {
  const baseClasses = "px-4 py-2 rounded-full text-sm font-medium transition-all duration-200 cursor-pointer whitespace-nowrap border";
  const selectedClasses = type === 'primary' 
    ? "bg-indigo-600 text-white border-indigo-500 shadow-lg shadow-indigo-500/30" 
    : "bg-emerald-600 text-white border-emerald-500 shadow-lg shadow-emerald-500/30";
  const unselectedClasses = "bg-gray-800 text-gray-400 border-gray-700 hover:border-gray-500 hover:bg-gray-700";

  return (
    <button
      onClick={onClick}
      className={`${baseClasses} ${isSelected ? selectedClasses : unselectedClasses}`}
    >
      {label}
    </button>
  );
};

export default Chip;
