
import { PromptOption, WritingSkill } from './types';

export const SHORTCUT_SHEET_CSV_URL = "https://docs.google.com/spreadsheets/d/14Vy2jo8DNDyedcyaOEXbP-21x0CQs57stFejhpEVlHI/export?format=csv&gid=0";

export const FORMATS = [
  { id: 'text', label: 'Text', icon: 'Type', color: 'bg-slate-700', shadow: 'shadow-slate-200' },
  { id: 'image', label: 'Image', icon: 'Image', color: 'bg-blue-600', shadow: 'shadow-blue-200' },
  { id: 'video', label: 'Video', icon: 'Video', color: 'bg-purple-600', shadow: 'shadow-purple-200' },
  { id: 'hindi_film', label: 'Hindi Film', icon: 'Clapperboard', color: 'bg-orange-600', shadow: 'shadow-orange-200' },
  { id: 'story', label: 'Story', icon: 'BookOpen', color: 'bg-emerald-600', shadow: 'shadow-emerald-200' },
];

export const WRITING_SKILLS: { id: WritingSkill, label: string }[] = [
  { id: 'none', label: 'Default Style' },
  { id: 'rewrite', label: 'Rewrite & Polish' },
  { id: 'professional', label: 'Professional Tone' },
  { id: 'personal', label: 'Personal / Casual' },
  { id: 'friendly', label: 'Friendly & Warm' },
  { id: 'informative', label: 'Informative / Technical' },
  { id: 'creative', label: 'Creative / Artistic' },
];

export const CATEGORIES = [
  { id: 'subject', label: 'Subject', icon: 'User', color: 'bg-blue-500', textColor: 'text-blue-500', formats: ['image', 'video', 'hindi_film', 'text'] },
  { id: 'vibe', label: 'Mood', icon: 'Heart', color: 'bg-rose-500', textColor: 'text-rose-500', formats: ['image', 'video', 'hindi_film', 'story', 'text'] },
  { id: 'motion', label: 'Motion', icon: 'Activity', color: 'bg-indigo-500', textColor: 'text-indigo-500', formats: ['video'] },
  { id: 'audio', label: 'Audio', icon: 'Music', color: 'bg-amber-500', textColor: 'text-amber-500', formats: ['video', 'hindi_film'] },
  { id: 'style', label: 'Style', icon: 'Palette', color: 'bg-purple-500', textColor: 'text-purple-500', formats: ['image', 'video', 'text'] },
  { id: 'camera', label: 'Camera', icon: 'Camera', color: 'bg-emerald-500', textColor: 'text-emerald-500', formats: ['image', 'video', 'hindi_film'] },
  { id: 'lighting', label: 'Light', icon: 'Zap', color: 'bg-orange-400', textColor: 'text-orange-400', formats: ['image', 'video', 'hindi_film'] },
  { id: 'reference', label: 'Ref', icon: 'Link', color: 'bg-cyan-500', textColor: 'text-cyan-500', formats: ['image', 'video'] },
  { id: 'custom', label: 'Extra', icon: 'PlusCircle', color: 'bg-slate-700', textColor: 'text-slate-700', formats: ['image', 'video', 'hindi_film', 'story', 'text'] },
];

export const OPTIONS: PromptOption[] = [
  // SUBJECTS
  { id: 'portrait', label: 'Face', value: 'Close-up face portrait, hyper-realistic detail', category: 'subject', iconName: 'User' },
  { id: 'cyber', label: 'Cyborg', value: 'Cybernetic humanoid with glowing implants', category: 'subject', iconName: 'Cpu' },
  { id: 'mythic', label: 'Deity', value: 'Ancient mythological god in celestial realm', category: 'subject', iconName: 'Sparkles' },
  { id: 'sci_fi', label: 'Pilot', value: 'Spaceship pilot in advanced flight suit', category: 'subject', iconName: 'Rocket' },
  { id: 'urban', label: 'Street', value: 'Cinematic candid street photography of city life', category: 'subject', iconName: 'Map' },
  { id: 'landscape', label: 'Vista', value: 'Wide expansive mountain range under twilight', category: 'subject', iconName: 'Mountain' },
  { id: 'architecture', label: 'Modern', value: 'Futuristic parametric skyscraper design', category: 'subject', iconName: 'Building' },
  { id: 'creature', label: 'Beast', value: 'Terrifying eldritch horror monster', category: 'subject', iconName: 'Bird' },
  { id: 'knight', label: 'Knight', value: 'Medieval knight in ornate plate armor', category: 'subject', iconName: 'Shield' },
  { id: 'forest', label: 'Forest', value: 'Ancient enchanted overgrown forest', category: 'subject', iconName: 'Trees' },
  { id: 'robot', label: 'Bot', value: 'Industrial assembly robot arm', category: 'subject', iconName: 'Bot' },
  { id: 'samurai', label: 'Samurai', value: 'Lone samurai in heavy rain, cinematic', category: 'subject', iconName: 'Sword' },

  // MOOD / VIBE
  { id: 'epic', label: 'Epic', value: 'Grand cinematic scale, legendary feel', category: 'vibe', iconName: 'Globe' },
  { id: 'noir', label: 'Noir', value: 'Moody dark shadows, high contrast black and white', category: 'vibe', iconName: 'Moon' },
  { id: 'dreamy', label: 'Dreamy', value: 'Soft ethereal hazy dreamlike atmosphere', category: 'vibe', iconName: 'Cloud' },
  { id: 'dynamic', label: 'Action', value: 'High intensity, kinetic energy, fast-paced', category: 'vibe', iconName: 'Zap' },
  { id: 'nostalgic', label: '90s', value: 'Vintage nostalgic 90s analog aesthetic', category: 'vibe', iconName: 'History' },
  { id: 'somber', label: 'Somber', value: 'Quiet melancholic brooding mood', category: 'vibe', iconName: 'CloudRain' },
  { id: 'serene', label: 'Zen', value: 'Peaceful tranquil meditative atmosphere', category: 'vibe', iconName: 'Wind' },
  { id: 'neon_vibe', label: 'Neon', value: 'Vivid synthwave neon cyberpunk glow', category: 'vibe', iconName: 'Sun' },

  // MOTION
  { id: 'panning', label: 'Pan', value: 'Cinematic horizontal camera pan', category: 'motion', iconName: 'MoveRight' },
  { id: 'zoom_in', label: 'Push', value: 'Slow dramatic push-in zoom', category: 'motion', iconName: 'ZoomIn' },
  { id: 'orbit', label: 'Orbit', value: 'Full 360-degree camera orbit', category: 'motion', iconName: 'RefreshCw' },
  { id: 'slow_mo', label: 'Slow', value: 'Ultra slow motion 120fps physics', category: 'motion', iconName: 'Clock' },
  { id: 'handheld', label: 'Shake', value: 'Documentary style handheld camera shake', category: 'motion', iconName: 'Hand' },

  // AUDIO
  { id: 'narrator', label: 'Voice', value: 'Deep professional male narrator voiceover', category: 'audio', iconName: 'Mic' },
  { id: 'synth', label: 'Synth', value: 'Pulsing electronic synthesizer soundtrack', category: 'audio', iconName: 'Music2' },
  { id: 'lofi', label: 'Lofi', value: 'Chill lofi hip hop beats, cozy vibe', category: 'audio', iconName: 'Coffee' },
  { id: 'orchestra', label: 'Score', value: 'Epic cinematic orchestral background score', category: 'audio', iconName: 'Music' },
  { id: 'thunder', label: 'Nature', value: 'Sound of heavy rain and distant thunder', category: 'audio', iconName: 'CloudLightning' },

  // STYLE
  { id: 'anime', label: 'Anime', value: 'High fidelity modern anime art style', category: 'style', iconName: 'Gamepad2' },
  { id: 'oil', label: 'Oil', value: 'Classical thick impasto oil painting', category: 'style', iconName: 'Brush' },
  { id: 'vector', label: 'Flat', value: 'Clean minimalist vector illustration', category: 'style', iconName: 'Pen' },
  { id: 'sketch', label: 'Pencil', value: 'Raw graphite pencil drawing sketch', category: 'style', iconName: 'PenTool' },
  { id: 'glitch', label: 'Glitch', value: 'Digital glitch art artifacts aesthetic', category: 'style', iconName: 'Zap' },

  // CAMERA
  { id: 'macro', label: 'Macro', value: 'Microscopic extreme close up detail', category: 'camera', iconName: 'Search' },
  { id: 'wide', label: 'Wide', value: 'Ultra wide angle panoramic perspective', category: 'camera', iconName: 'Maximize' },
  { id: 'drone', label: 'Aerial', value: 'Top down bird\'s eye view drone shot', category: 'camera', iconName: 'Wind' },
  { id: 'pov', label: 'POV', value: 'First person immersive perspective', category: 'camera', iconName: 'Eye' },

  // LIGHTING
  { id: 'neon_light', label: 'Neon', value: 'Vivid blue and pink neon lighting', category: 'lighting', iconName: 'Zap' },
  { id: 'sunset', label: 'Sunset', value: 'Warm golden hour sunset backlighting', category: 'lighting', iconName: 'Sunrise' },
  { id: 'soft', label: 'Soft', value: 'Diffused cinematic studio lighting', category: 'lighting', iconName: 'Sun' },
  { id: 'dramatic', label: 'High Key', value: 'Strong high contrast dramatic shadows', category: 'lighting', iconName: 'Focus' },

  // REFERENCE
  { id: 'cref', label: 'Person', value: '--cref', category: 'reference', iconName: 'UserCheck' },
  { id: 'sref', label: 'Style', value: '--sref', category: 'reference', iconName: 'Palette' },
];

export const BASE_POSITIVE_TOKENS = ['ultra-detailed', 'masterpiece', '8k'];
export const BASE_NEGATIVE_TOKENS = ['lowres', 'blur', 'ugly'];
