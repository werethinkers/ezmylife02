
import { SelectionState, PromptState, AIModelTarget, OutputFormat, CustomTag, WritingSkill } from '../types';
import { OPTIONS, BASE_POSITIVE_TOKENS, BASE_NEGATIVE_TOKENS } from '../constants';

export const buildPrompt = (
  context: string, 
  selections: SelectionState, 
  model: AIModelTarget, 
  customTags: CustomTag[] = [],
  branding: { logo: string; text: string },
  writingSkill: WritingSkill = 'none'
): PromptState => {
  let primaryParts = context.trim() ? [context.trim()] : [];
  let positiveSet = new Set<string>();
  let negativeSet = new Set<string>();
  let outputType = selections['format']?.[0] || 'text';

  // Only use base tokens for visual formats
  if (['image', 'video', 'hindi_film'].includes(outputType)) {
    BASE_POSITIVE_TOKENS.forEach(t => positiveSet.add(t));
    BASE_NEGATIVE_TOKENS.forEach(t => negativeSet.add(t));
  }

  const order = ['subject', 'vibe', 'motion', 'audio', 'style', 'camera', 'lighting'];

  order.forEach(catId => {
    const selectedIds = selections[catId] || [];
    selectedIds.forEach(id => {
      const opt = OPTIONS.find(o => o.id === id);
      if (opt) {
        primaryParts.push(opt.value);
        // Only collect visual tokens for visual formats
        if (['image', 'video', 'hindi_film'].includes(outputType)) {
          if (opt.positiveTokens) opt.positiveTokens.forEach(t => positiveSet.add(t));
          if (opt.negativeTokens) opt.negativeTokens.forEach(t => negativeSet.add(t));
        }
      }
    });
  });

  const activeCustomIds = selections['custom'] || [];
  activeCustomIds.forEach(id => {
    const custom = customTags.find(t => t.id === id);
    if (custom) {
      primaryParts.push(custom.value);
    }
  });

  if (branding.logo) primaryParts.push(`logo: "${branding.logo}"`);
  if (branding.text) primaryParts.push(`text: "${branding.text}"`);

  return {
    primary: primaryParts.filter(Boolean).join(', '),
    positive: Array.from(positiveSet).join(', '),
    negative: Array.from(negativeSet).join(', '),
    outputType,
    branding,
    writingSkill
  };
};

export const formatOutput = (prompt: PromptState, format: OutputFormat, model: AIModelTarget): string => {
  let finalPrimary = prompt.primary;
  
  if (prompt.writingSkill !== 'none') {
    const skillPrefixes: Record<WritingSkill, string> = {
      none: '',
      rewrite: '[REWRITE]',
      professional: '[PROFESSIONAL]',
      personal: '[PERSONAL]',
      friendly: '[FRIENDLY]',
      informative: '[INFORMATIVE]',
      creative: '[CREATIVE]'
    };
    finalPrimary = `${skillPrefixes[prompt.writingSkill]} ${finalPrimary}`;
  }

  if (prompt.outputType === 'hindi_film') {
    finalPrimary = `[HINDI FILM SCRIPT] ${finalPrimary}. Act as a Bollywood scriptwriter.`;
  } else if (prompt.outputType === 'video') {
    finalPrimary = `[VIDEO PROMPT] ${finalPrimary}. Cinematic movement.`;
  } else if (prompt.outputType === 'story') {
    finalPrimary = `[NARRATIVE STORY] ${finalPrimary}. Literary style.`;
  } else if (prompt.outputType === 'text') {
    // For text mode, we just return the primary content without image-gen suffixes
    return finalPrimary;
  }

  switch (format) {
    case OutputFormat.STRUCTURED:
      return `TYPE: ${prompt.outputType.toUpperCase()}\nCONTENT:\n${finalPrimary}\n\nSTYLING:\n${prompt.positive}\n\nNO:\n${prompt.negative}`;
    case OutputFormat.MIDJOURNEY_SYNTAX:
      return `${finalPrimary}${prompt.positive ? ', ' + prompt.positive : ''} ${prompt.negative ? '--no ' + prompt.negative.replace(/,/g, '') : ''}`;
    default:
      return `${finalPrimary}${prompt.positive ? ', ' + prompt.positive : ''}`;
  }
};
