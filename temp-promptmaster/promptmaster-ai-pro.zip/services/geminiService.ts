
import { GoogleGenAI, Type } from "@google/genai";
import { Variation } from "../types";

export const suggestSimilarPrompts = async (context: string, currentSelections: string[], format: string): Promise<Variation[]> => {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    
    const isText = format === 'text';
    const goal = isText 
      ? "Rewrite or expand this message for different professional or social contexts." 
      : "Generate creative variations of an image/video prompt.";

    const contents = `Task: ${goal}
      Source Input: "${context}"
      Keywords/Style: ${currentSelections.join(', ')}
      Target Format: ${format.toUpperCase()}
      
      Generate exactly 5 distinct variations. 
      If format is TEXT, focus on tone, clarity, and impact.
      If format is IMAGE/VIDEO, focus on visual description, lighting, and composition.
      
      Provide a short catchy title for each.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING },
              prompt: { type: Type.STRING }
            },
            required: ['title', 'prompt']
          }
        }
      }
    });

    const text = response.text;
    if (text) {
      return JSON.parse(text);
    }
    return [];
  } catch (error) {
    console.error("Gemini suggestion failed:", error);
    return [];
  }
};

export const magicWrite = async (keywords: string, format: string): Promise<Variation[]> => {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    
    const isText = format === 'text';
    const instruction = isText
      ? "Perform 'Magic Write' on this draft. Expand it into 3 distinct, highly polished versions (e.g., Persuasive, Concise, Creative)."
      : "Perform 'Magic Write' on these keywords. Expand them into 3 distinct, highly descriptive, and artistic visual prompt variations.";

    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Input: "${keywords}"
      Format: ${format.toUpperCase()}
      Instruction: ${instruction}
      
      Provide a title for each.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING },
              prompt: { type: Type.STRING }
            },
            required: ['title', 'prompt']
          }
        }
      }
    });

    const text = response.text;
    return text ? JSON.parse(text) : [];
  } catch (err) {
    console.error("Magic Write failed:", err);
    return [];
  }
};
