

import { GoogleGenAI, Chat, GenerateContentResponse } from "@google/genai";
import type { AnalysisResult, StructuredData, Company } from "../types";

// This tells TypeScript that pdfjsLib is a global variable provided by the script in index.html
declare const pdfjsLib: any;

// Configure the worker to enable PDF.js to process files in the background
if (typeof pdfjsLib !== 'undefined') {
  pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://unpkg.com/pdfjs-dist@4.4.168/build/pdf.worker.min.mjs';
}

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
    throw new Error("API_KEY environment variable not set.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

// --- Google Sheet & Drive Integration ---

/**
 * Parses raw CSV text into a 2D array, correctly handling quoted fields.
 * @param text The raw CSV text.
 * @returns A 2D array of strings representing the parsed data.
 */
function parseCSV(text: string): string[][] {
  const lines = text.replace(/\r/g, '').trim().split('\n');
  return lines.map(line => {
    // This regex splits by comma, but ignores commas inside double quotes.
    const fields = line.split(/,(?=(?:(?:[^"]*"){2})*[^"]*$)/);
    // Remove the surrounding quotes from each field and trim whitespace.
    return fields.map(field => field.replace(/^"|"$/g, '').trim());
  });
}

/**
 * Fetches and parses company data from the hardcoded public Google Sheet.
 * @returns A promise that resolves to an array of Company objects.
 */
export async function fetchCompanies(): Promise<Company[]> {
    const SHEET_ID = '1GAuIZI5u-6rvwvi08F0QMsRFqhPUlyIRcJU-a6vuTq0';
    const url = `https://docs.google.com/spreadsheets/d/${SHEET_ID}/gviz/tq?tqx=out:csv`;

    try {
        const response = await fetch(url);
        if (!response.ok) {
            throw new Error(`Failed to fetch Google Sheet: ${response.statusText}`);
        }
        const csvText = await response.text();
        const parsedData = parseCSV(csvText);
        
        const header = parsedData[0] || [];
        const nameIndex = header.indexOf('Company Name');
        const urlIndex = header.indexOf('Pitch Deck URL'); // Corrected from 'Pitch Deck (Drive Link)'
        const websiteIndex = header.indexOf('Company Website');

        if (nameIndex === -1 || urlIndex === -1) {
            console.error("Sheet headers found:", header);
            const missing = [];
            if (nameIndex === -1) missing.push("'Company Name'");
            if (urlIndex === -1) missing.push("'Pitch Deck URL'");
            throw new Error(`Could not find required columns ${missing.join(' and ')} in the Google Sheet.`);
        }
        
        const dataRows = parsedData.slice(1);
        
        const companies: Company[] = dataRows.map(row => {
            const companyName = row[nameIndex];
            const pitchDeckUrl = row[urlIndex];

            if (!companyName || !pitchDeckUrl) return null;

            // Use the website from the sheet if available, otherwise generate one.
            const website = (websiteIndex !== -1 && row[websiteIndex]) 
                ? row[websiteIndex].trim() 
                : companyName.trim().toLowerCase().replace(/[^a-z0-9]/g, '') + '.com';

            return {
                name: companyName.trim(),
                pitchDeckUrl: pitchDeckUrl.trim(),
                website,
            };
        }).filter((c): c is Company => c !== null && c.name !== '');

        return companies;

    } catch (error) {
        console.error("Error fetching or parsing company data from Google Sheet:", error);
        if (error instanceof Error && error.message.startsWith('Could not find required columns')) {
             throw error; // Re-throw our specific error
        }
        throw new Error("Could not load company data. Please ensure the Google Sheet is public, has the correct link, and includes 'Company Name' and 'Pitch Deck URL' columns.");
    }
}

/**
 * Fetches a pitch deck from a Google Drive or Google Slides URL and returns it as a File object.
 * This uses a CORS proxy to bypass browser restrictions on direct downloads.
 * @param url The public URL to the Google Drive file or Google Slides presentation.
 * @returns A promise that resolves to a PDF File object.
 */
export async function fetchPitchDeckAsFile(url: string): Promise<File> {
    let downloadUrl = '';
    let fileId = '';

    const slideMatch = url.match(/presentation\/d\/([a-zA-Z0-9_-]+)/);
    const driveMatch = url.match(/file\/d\/([a-zA-Z0-9_-]+)/);

    if (slideMatch?.[1]) {
        fileId = slideMatch[1];
        downloadUrl = `https://docs.google.com/presentation/d/${fileId}/export/pdf`;
    } else if (driveMatch?.[1]) {
        fileId = driveMatch[1];
        downloadUrl = `https://drive.google.com/uc?export=download&id=${fileId}`;
    } else {
        throw new Error("Invalid Google Drive or Google Slides URL provided.");
    }
    
    // Use a CORS proxy to bypass browser restrictions.
    // CRITICAL: The target URL must be encoded to work correctly with the proxy.
    const proxyUrl = `https://api.codetabs.com/v1/proxy/?quest=${encodeURIComponent(downloadUrl)}`;
    
    try {
        const response = await fetch(proxyUrl);
        if (!response.ok) {
            throw new Error(`Failed to download file via proxy (codetabs): ${response.status} ${response.statusText}`);
        }
        const blob = await response.blob();
        
        // A robust check to ensure the downloaded file is actually a PDF.
        // Google Drive often returns an HTML page (login, error, etc.) if permissions are wrong.
        // We check the "magic number" (the first few bytes) at the start of the file.
        if (blob.size < 5) {
             throw new Error("Downloaded file is too small to be a valid PDF. Please check the sharing permissions of the file in Google Drive/Slides and ensure it's set to 'Anyone with the link can view'.");
        }

        const fileStart = await blob.slice(0, 5).text();
        if (fileStart !== '%PDF-') {
            // Provide a very specific error message to the user.
            throw new Error("Downloaded file is not a valid PDF. This usually happens if the file's sharing permissions are not set to 'Anyone with the link can view'. Please check the link and permissions in Google Drive/Slides.");
        }
        
        return new File([blob], "pitch-deck.pdf", { type: 'application/pdf' });

    } catch(error) {
        console.error("Error fetching pitch deck:", error);
        if (error instanceof Error) {
            if (error.message.includes('Failed to fetch')) {
                 throw new Error("A network error occurred while fetching the pitch deck. This may be due to the CORS proxy service (codetabs) being unavailable or a network connectivity issue.");
            }
            throw error; // Re-throw our specific validation error or other fetch errors.
        }
        throw new Error("An unexpected error occurred while fetching the pitch deck.");
    }
}


/**
 * Wraps the ai.models.generateContent call with a retry mechanism.
 * @param params The parameters for the generateContent call.
 * @param retries The number of times to retry on failure.
 * @param initialDelay The initial delay between retries, in milliseconds.
 * @returns The response from the API.
 */
async function generateContentWithRetry(
    params: Parameters<typeof ai.models.generateContent>[0],
    retries = 3,
    initialDelay = 1000
): Promise<GenerateContentResponse> {
    let lastError: unknown;
    for (let i = 0; i < retries; i++) {
        try {
            return await ai.models.generateContent(params);
        } catch (error) {
            lastError = error;
            console.error(`Gemini API call failed. Attempt ${i + 1} of ${retries}.`, error);
            
            if (i < retries - 1) {
                const delay = initialDelay * Math.pow(2, i); // Exponential backoff
                console.log(`Retrying in ${delay}ms...`);
                await new Promise(resolve => setTimeout(resolve, delay));
            }
        }
    }
    console.error("Gemini API call failed after all retries.");
    if (lastError instanceof Error) {
        throw new Error(`Gemini API call failed after all retries: ${lastError.message}`);
    }
    // If the error is an object (like the API error response), stringify it for better logging.
    throw new Error(`Gemini API call failed after all retries: ${JSON.stringify(lastError)}`);
}


async function convertPageToImage(page: any): Promise<string> {
    const viewport = page.getViewport({ scale: 1.0 });
    const canvas = document.createElement('canvas');
    const context = canvas.getContext('2d');
    canvas.height = viewport.height;
    canvas.width = viewport.width;

    if (!context) throw new Error('Could not get canvas context');
    
    await page.render({ canvasContext: context, viewport: viewport }).promise;
    return canvas.toDataURL('image/jpeg', 0.85).split(',')[1];
}

async function convertPdfToImages(file: File, onProgress: (progress: number) => void): Promise<string[]> {
    if (typeof pdfjsLib === 'undefined') {
        throw new Error("PDF.js library is not loaded.");
    }
    
    const fileReader = new FileReader();

    return new Promise((resolve, reject) => {
        fileReader.onload = async (event) => {
            if (!event.target?.result) return reject(new Error('Failed to read file.'));
            try {
                const typedarray = new Uint8Array(event.target.result as ArrayBuffer);
                const pdf = await pdfjsLib.getDocument(typedarray).promise;
                const imagePromises: Promise<string>[] = [];
                const maxPages = Math.min(pdf.numPages, 10);

                for (let i = 1; i <= maxPages; i++) {
                    onProgress(i / maxPages); // Report progress from 0.0 to 1.0
                    const page = await pdf.getPage(i);
                    imagePromises.push(convertPageToImage(page));
                }

                resolve(await Promise.all(imagePromises));
            } catch (error) {
                reject(error);
            }
        };
        fileReader.onerror = reject;
        fileReader.readAsArrayBuffer(file);
    });
}

const getAnalysisPrompt = (companyName: string, companyWebsite: string, hasPitchDeck: boolean): string => {
    const primarySourceInstruction = hasPitchDeck
      ? `**PRIMARY SOURCE**: A pitch deck has been provided. You MUST prioritize the information within this deck for your analysis. Use web search to supplement, verify, and enrich the information, but the pitch deck is the foundational source of truth.`
      : `**PRIMARY SOURCE**: No pitch deck provided. Rely on your web search capabilities to conduct a thorough analysis based on publicly available information.`;

    return `You are a world-class venture capital analyst. Your task is to generate an Investment Committee (IC) Note for the startup "${companyName}" (${companyWebsite}).

${primarySourceInstruction}

**CRITICAL DIRECTIVE: BE EXHAUSTIVE.** You must generate content for **every single heading** in the markdown report template below. Similarly, you must provide a value for **every single key** in the JSON data structure. If information is not available, you must explicitly state "Information not publicly available" for that section or key. **DO NOT OMIT ANY SECTIONS OR KEYS.**

Structure your response into two distinct parts: a detailed markdown report and a structured JSON object.

**PART 1: MARKDOWN REPORT (IC NOTE FORMAT)**
Generate a comprehensive markdown report following this exact structure. Do not skip any sections. The content in each markdown section MUST be identical to the content you provide in the corresponding structured JSON fields in Part 2.

# IC NOTE: ${companyName}
- **Website**: ${companyWebsite}
- **Industry**:
- **Description**:
- **Year Of Foundation**:

## Executive Summary
*(This section in markdown should be a high-level summary. The detailed, structured version will be in the JSON's 'executiveSummaryData' object.)*

## Market
- **History Of This Tech In India**:
- **Market Size & TAM/SAM/SOM**:
- **Market Overview Across all verticals**:
- **Upstream And Downstream**:
- **Market Challenges**:
- **Innovations Leading The Change**:

## Problem In Detail

## Solution In Detail

## Products

## Pictorial Technology Definition
*CRITICAL: Generate a simple, valid Mermaid.js 'graph TD' diagram that visually explains the company's technology, architecture, or business process.
**IMPORTANT RULES:**
1.  **NO SEMICOLONS:** Each statement MUST be on a new line. DO NOT use semicolons (;) to separate statements.
2.  **SIMPLE SYNTAX:** Do not use complex features like 'style' or 'classDef' directives. Keep the diagram clean.
3.  **QUOTES:** All text for node labels and edge labels MUST be enclosed in double quotes. e.g., \`A["Node Text"] -- "Edge Text" --> B["Another Node"]\`. Do not use single quotes or backticks inside the labels.
4.  **ENCLOSURE:** The entire diagram definition MUST be enclosed in a \`\`\`mermaid ... \`\`\` code block.

**EXAMPLE of CORRECT SYNTAX:**
\`\`\`mermaid
graph TD
    A["Step 1: User Input"] --> B["Step 2: Processing"]
    B --> C{"Decision Point"}
    C -- "Path A" --> D["Outcome 1"]
    C -- "Path B" --> E["Outcome 2"]
\`\`\`*

## USP/MOAT

## IP (Intellectual Property)

## Competition Landscape
*CRITICAL: You MUST find at least 5-7 Indian competitors and 5-7 Global competitors. For each competitor, provide a detailed analysis covering their funding, valuation, technological advantages, and how "${companyName}" is better than them. Present this data in the markdown tables below.*

### Indian Competitors
| Company | Website | HQ | Funding | Valuation | Core Product | Tech Advantage | Our Advantage |
|---|---|---|---|---|---|---|---|
| [Competitor Name] | [competitor.com] | City, India | $XM | $Y00M | ... | ... | ... |

### Global Competitors
| Company | Website | HQ | Funding | Valuation | Core Product | Tech Advantage | Our Advantage |
|---|---|---|---|---|---|---|---|
| [Competitor Name] | [competitor.com] | City, Country | $YM | $ZB | ... | ... | ... |

### Competitors across all verticals
*(Provide a brief analysis of how the company competes or fits within the broader ecosystem).*

## Traction

## Business Model

## Team
*For each founder, provide their name, title, a brief bio, and a markdown-formatted link to their LinkedIn profile. e.g., **[Founder Name](https://linkedin.com/in/profilename)** - CEO & Co-founder. CRITICAL: Use web search to find any other directorships, ownership, or board positions held by the founders. List the other company's name, a brief detail about it, and the position held.*

## Fundraises

## Investment Required

## Use Of Investments

## Financial Plan

## Expert Opinion

## Exit Plan
- **Examples Of Secondary Sale**:
- **Examples Of Acquisition**:
- **Examples Of IPO**:

## Investment Risk (Including Regulatory & Compliance Risks)
*Detail all potential risks. Specifically analyze regulatory hurdles and compliance requirements, particularly under Indian law (e.g., FEMA, Companies Act, data privacy laws). What happens if they fail to comply?*

## Investment Rationale (Including Potential Incentives)
*What makes this a compelling investment? Include analysis of potential government incentives, certifications, or compliance benefits (e.g., under Startup India, Make in India) that could act as a positive catalyst.*

## Conclusion

## Future Roadmap

## Legal & Compliance
### Founder Legal Issues
*(Use your search tool to find and detail any past or ongoing legal issues, lawsuits, or regulatory concerns involving the founders based on public records. If none, state that clearly.)*

### Company Legal Issues
*(Use your search tool to find and detail any past or ongoing legal issues, lawsuits, or regulatory concerns involving the company itself. If none, state that clearly.)*


## Appendix / Reference links
*(This section will be populated by the grounding sources you use)*

**PART 2: JSON DATA**
After the markdown report, include a single JSON object enclosed in \`\`\`json ... \`\`\`.
**CRITICAL INSTRUCTIONS FOR JSON:**
1.  **MANDATORY FIELDS**: You must provide a value for every single key in the JSON object. Do not omit any keys. If information is unavailable, follow these rules:
    -   For \`SourcedDataPoint[]\` fields, return an array with a single object: \`[{ "value": "Information not publicly available", "sourceType": "model_knowledge", "sourceDetail": "N/A" }]\`.
    -   For other array fields (like \`indian_competitors\`), use an empty array \`[]\`.
    -   For simple string fields, use "Information not publicly available".
    -   For numeric fields, use \`0\`.
2.  **STRUCTURED IC NOTE FIELDS**: Many top-level fields (e.g., \`problem_in_detail\`, \`solution_in_detail\`, \`market_analysis\`) now require a \`SourcedDataPoint[]\` array, not just a string. You MUST populate these fields with the same detailed, multi-bullet-point content from the markdown report, but structured into an array of sourced data points. Each bullet point from the markdown should become a separate \`value\` in a \`SourcedDataPoint\` object.
3.  **PICTORIAL DEFINITION**: The \`pictorial_technology_definition\` field MUST contain the raw Mermaid.js diagram definition string as the \`value\` in its \`SourcedDataPoint\` array.
4.  **KEYWORDS**: In the 'keywords' field, identify the most important business and technical terms from your analysis. Provide up to 15 keywords in total, split between the 'business' and 'technical' arrays.
5.  **COMPETITOR ANALYSIS**: You **MUST** find and analyze at least 5-7 competitors for both the 'indian_competitors' and 'global_competitors' arrays. The analysis for each must be detailed and fill all the new fields: 'valuation', 'tech_advantage', and 'user_co_advantage'.
6.  **DYNAMIC CHARTS**: The 'indian_competitor_chart_data' and 'global_competitor_chart_data' must be generated dynamically. The 'labels' array for each chart must include the names of **all** competitors found, plus "${companyName}". The 'data' array must contain the corresponding 'fundingAmount' for each entity in the same order.
7.  **CHART COLORS**: Generate a unique hex color code for each bar's 'backgroundColor' and 'borderColor' in the chart data.
8.  **MONETARY VALUES**: All monetary values must be in USD and represented as a number, not a string.
9.  **ULTRA-DETAILED EXECUTIVE SUMMARY**: For the 'executiveSummaryData' object, your analysis must be exceptionally detailed and comprehensive. For each 'value' field, provide a series of detailed bullet points. **CRITICAL FORMATTING RULE**: Each bullet point MUST start with a hyphen (-) followed by a bolded 1-2 word summary of the point, a colon, and then the full text. For example: "- **Handheld Datacenter:** The company is building the world's first handheld data center powered by DNA." Do not use long paragraphs. Each bullet point should represent a distinct piece of information. Provide multiple data points from different sources (pitch deck, web, model knowledge). The goal is to create a rich, dense, and easily scannable summary. Be verbose and exhaustive.
10. **COMPLETENESS**: Do not include any other text after the JSON block.
11. **JSON VALIDITY**: You MUST ensure the generated JSON is perfectly valid. Pay special attention to escaping characters within strings.
12. **RESOURCES**: Use your search tool to find and populate the \`news_articles\`, \`youtube_videos\`, and \`research_papers\` arrays. You MUST find up to 5 relevant news articles, 5 relevant YouTube videos, and 5 relevant research papers.
13. **MULTI-SOURCE MARKET SIZE CHART**: For 'market_size_chart_data', you must gather data from up to 2-3 sources (reports + pitch deck if available). Each source must be a separate dataset object with a clearly named label.
14. **SUB-CATEGORY MARKET ANALYSIS**: You MUST find data on the market's sub-categories and generate \`market_subcategory_share_chart_data\` (pie/donut) and \`market_subcategory_growth_chart_data\` (line).
15. **LEGAL & FOUNDER ANALYSIS**: Use your search capabilities to populate the 'legal_analysis' and founder 'other_positions' sections with detailed, sourced findings. If none, use empty arrays or state it clearly.
16. **EXIT OPTIONS EXAMPLES**: Provide at least 2-3 real-world company examples for 'exit_options_ipo' and 'exit_options_acquisition'.
17. **FINANCIAL PROJECTIONS**: You MUST extract a 3-5 year financial projection table **exclusively from the pitch deck** if available. Populate the 'financial_projections' object. If not available, use default empty values (empty headers and rows arrays).

{
  "name": "${companyName}",
  "website": "${companyWebsite}",
  "industry": "...",
  "description": "...",
  "founded_year": "...",
  "location": "...",
  "market_analysis": [
    { "value": "- **History of Tech:** ...", "sourceType": "web_search", "sourceDetail": "URL" }
  ],
  "problem_in_detail": [
    { "value": "- **Core Problem:** ...", "sourceType": "pitch_deck", "sourceDetail": "Slide 3" }
  ],
  "solution_in_detail": [
    { "value": "- **Core Solution:** ...", "sourceType": "pitch_deck", "sourceDetail": "Slide 4" }
  ],
  "products_analysis": [
    { "value": "- **Product A:** ...", "sourceType": "pitch_deck", "sourceDetail": "Slide 9" }
  ],
  "pictorial_technology_definition": [
    { "value": "graph TD; A[\\"Start\\"] --> B{\\"Decision?\\"};", "sourceType": "model_knowledge", "sourceDetail": "N/A" }
  ],
  "usp_moat": [
    { "value": "- **Key Differentiator:** ...", "sourceType": "pitch_deck", "sourceDetail": "Slide 7" }
  ],
  "ip_summary": [
    { "value": "- **Patents:** ...", "sourceType": "web_search", "sourceDetail": "URL to patent office" }
  ],
  "competition_summary": [
    { "value": "- **Overview:** A text summary of the competitive landscape. Full details are in the competitor arrays and charts.", "sourceType": "model_knowledge", "sourceDetail": "N/A" }
  ],
  "traction_summary": [
    { "value": "- **Key Metrics:** ...", "sourceType": "pitch_deck", "sourceDetail": "Slide 10" }
  ],
  "business_model": [
    { "value": "- **Monetization:** ...", "sourceType": "pitch_deck", "sourceDetail": "Slide 11" }
  ],
  "team_summary": [
    { "value": "- **Overall Strength:** ... Full details in Executive Summary.", "sourceType": "model_knowledge", "sourceDetail": "N/A" }
  ],
  "fundraises_summary": [
    { "value": "- **Past Rounds:** ...", "sourceType": "web_search", "sourceDetail": "URL of funding announcement" }
  ],
  "investment_required": [
    { "value": "- **The Ask:** $5M Series A", "sourceType": "pitch_deck", "sourceDetail": "Slide 15" }
  ],
  "use_of_investments": [
    { "value": "- **Allocation:** 40% R&D, 30% Marketing...", "sourceType": "pitch_deck", "sourceDetail": "Slide 16" }
  ],
  "financial_plan_summary": [
    { "value": "- **Projections:** ...", "sourceType": "pitch_deck", "sourceDetail": "Slide 17" }
  ],
  "financial_projections": {
    "headers": ["Metric", "2025 (Projected)", "2026 (Projected)", "2027 (Projected)"],
    "rows": [
      { "metric": "Revenue (USD)", "values": [1000000, 5000000, 15000000] },
      { "metric": "COGS (USD)", "values": [200000, 1000000, 3000000] },
      { "metric": "Gross Profit (USD)", "values": [800000, 4000000, 12000000] },
      { "metric": "Operating Expenses (USD)", "values": [500000, 2000000, 5000000] },
      { "metric": "Net Profit/Loss (USD)", "values": [300000, 2000000, 7000000] }
    ],
    "source": { "sourceType": "pitch_deck", "sourceDetail": "Slide 17: Financials" }
  },
  "expert_opinion": [
    { "value": "- **Industry Analyst Quote:** ...", "sourceType": "web_search", "sourceDetail": "URL" }
  ],
  "exit_plan_summary": [
    { "value": "- **Potential Acquirers:** ...", "sourceType": "model_knowledge", "sourceDetail": "N/A" }
  ],
  "investment_risk": [
    { "value": "- **Market Risk:** ...", "sourceType": "model_knowledge", "sourceDetail": "N/A" }
  ],
  "investment_rationale": [
    { "value": "- **Primary Rationale:** ...", "sourceType": "model_knowledge", "sourceDetail": "N/A" }
  ],
  "conclusion": [
    { "value": "- **Final Recommendation:** ...", "sourceType": "model_knowledge", "sourceDetail": "N/A" }
  ],
  "future_roadmap": [
    { "value": "- **Q1 Next Year:** ...", "sourceType": "pitch_deck", "sourceDetail": "Slide 18" }
  ],
  "keywords": {
    "business": ["B2B SaaS", "Marketplace Model", "Go-to-Market Strategy"],
    "technical": ["Generative AI", "LLM Fine-tuning", "Vector Database"]
  },
  "news_articles": [
    {
      "title": "Article Title",
      "url": "https://example.com/news-article",
      "summary": "A brief summary of the article's content and its relevance to the startup.",
      "type": "news"
    }
  ],
  "youtube_videos": [
    {
      "title": "Video Title",
      "url": "https://www.youtube.com/watch?v=videoId",
      "summary": "A brief summary of the video's content and how it explains the technology or features the team.",
      "type": "youtube"
    }
  ],
  "research_papers": [
    {
      "title": "Research Paper Title",
      "url": "https://arxiv.org/abs/paperId",
      "summary": "A brief summary of the paper's abstract and its connection to the company's IP or technology.",
      "type": "paper"
    }
  ],
  "indian_competitors": [
    {
      "name": "Competitor Name",
      "website": "https://competitor.com",
      "hq": "City, India",
      "founding_year": "YYYY",
      "funding": "Funding Stage or Amount (e.g., '$50M' or 'Seed')",
      "fundingAmount": 50000000,
      "valuation": "$500M",
      "key_investors": ["Investor A", "Investor B"],
      "notable_clients": ["Client A", "Client B"],
      "recent_moves": "Description of recent strategic moves.",
      "core_product": "A brief description of their main product.",
      "tech_advantage": "Detailed analysis of their key technology and what gives them an edge.",
      "user_co_advantage": "Detailed analysis of where ${companyName} is superior, e.g., better tech, different GTM, stronger team."
    }
  ],
  "global_competitors": [
    {
      "name": "Competitor Name",
      "website": "https://competitor.com",
      "hq": "City, Country",
      "founding_year": "YYYY",
      "funding": "Funding Stage or Amount (e.g., '$50M' or 'Seed')",
      "fundingAmount": 50000000,
      "valuation": "$500M",
      "key_investors": ["Investor A", "Investor B"],
      "notable_clients": ["Client C", "Client D"],
      "recent_moves": "Description of recent strategic moves.",
      "core_product": "A brief description of their main product.",
      "tech_advantage": "Detailed analysis of their key technology and what gives them an edge.",
      "user_co_advantage": "Detailed analysis of where ${companyName} is superior, e.g., better tech, different GTM, stronger team."
    }
  ],
  "indian_competitor_chart_data": {
    "type": "bar",
    "labels": ["${companyName}", "Indian Competitor 1", "Indian Competitor 2"],
    "datasets": [{ "label": "Total Funding (USD)", "data": [10000000, 50000000, 25000000], "backgroundColor": ["#36a2eb", "#ff6384", "#ffcd56"], "borderColor": ["#36a2eb", "#ff6384", "#ffcd56"], "borderWidth": 1 }]
  },
  "global_competitor_chart_data": {
    "type": "bar",
    "labels": ["${companyName}", "Global Competitor 1", "Global Competitor 2"],
    "datasets": [{ "label": "Total Funding (USD)", "data": [10000000, 120000000, 80000000], "backgroundColor": ["#36a2eb", "#4bc0c0", "#9966ff"], "borderColor": ["#36a2eb", "#4bc0c0", "#9966ff"], "borderWidth": 1 }]
  },
  "market_size_chart_data": {
    "type": "line",
    "labels": ["2024", "2025", "2026", "2027", "2028"],
    "datasets": [
        {
            "label": "Pitch Deck Projection",
            "data": [15000000000, 20000000000, 28000000000, 35000000000, 45000000000],
            "borderColor": "#ff6384",
            "backgroundColor": "rgba(255, 99, 132, 0.2)",
            "fill": true,
            "tension": 0.4
        }
    ]
  },
  "market_subcategory_share_chart_data": {
    "type": "pie",
    "labels": ["Sub-Category A", "Sub-Category B", "Sub-Category C", "Others"],
    "datasets": [{
        "label": "Market Share",
        "data": [40, 30, 20, 10],
        "backgroundColor": ["#FF6384", "#36A2EB", "#FFCE56", "#E7E9ED"],
        "borderColor": ["#FFFFFF", "#FFFFFF", "#FFFFFF", "#FFFFFF"],
        "borderWidth": 2
    }]
  },
  "market_subcategory_growth_chart_data": {
    "type": "line",
    "labels": ["2024", "2025", "2026", "2027", "2028"],
    "datasets": [
        {
            "label": "Sub-Category A Growth",
            "data": [10, 12, 15, 18, 22],
            "borderColor": "#FF6384",
            "backgroundColor": "rgba(255, 99, 132, 0.2)",
            "fill": false,
            "tension": 0.4
        }
    ]
  },
   "comparisonMatrix": {
    "headers": ["Feature", "${companyName}", "Competitor A"],
    "rows": [
        ["Core Technology", "...", "..."],
        ["Pricing Model", "...", "..."]
    ]
  },
  "fundingTrends": "Description of funding trends in this sector.",
  "executiveSummaryData": {
    "startup_overview": {
        "name": [{ "value": "${companyName}", "sourceType": "model_knowledge", "sourceDetail": "Provided in prompt" }],
        "website": [{ "value": "${companyWebsite}", "sourceType": "model_knowledge", "sourceDetail": "Provided in prompt" }],
        "founding_year": [{ "value": "- **Deck Information:** Founded in YYYY as per pitch deck.", "sourceType": "pitch_deck", "sourceDetail": "Slide X" }],
        "location": [{ "value": "- **Headquarters:** City, Country (HQ)", "sourceType": "web_search", "sourceDetail": "URL of source" }],
        "sector_subsector": [{ "value": "- **Industry Focus:** Provide the specific Sector and Sub-sector, e.g., 'Fintech / Parametric Insurance'", "sourceType": "pitch_deck", "sourceDetail": "Slide 1" }],
        "investment_ask": [{ "value": "- **The Ask:** The specific investment ask, e.g., '$10M Series A on a $50M pre-money valuation'", "sourceType": "pitch_deck", "sourceDetail": "Slide 15: The Ask" }],
        "investment_committed": [{ "value": "- **Committed Capital:** Amount of the current round already committed, e.g., '$2M committed from Lead Investor X.'", "sourceType": "web_search", "sourceDetail": "URL of source" }],
        "investment_remaining": [{ "value": "- **Remaining:** e.g., '$8M'", "sourceType": "model_knowledge", "sourceDetail": "Calculated based on ask and committed funds" }],
        "stage": [{ "value": "- **Current Stage:** e.g., Pre-seed, Seed, Series A", "sourceType": "web_search", "sourceDetail": "URL of source" }],
        "date_of_review": [{ "value": "- **Review Date:** Today's Date", "sourceType": "model_knowledge", "sourceDetail": "N/A" }],
        "author_name": [{ "value": "- **Analyst:** AI Analyst", "sourceType": "model_knowledge", "sourceDetail": "N/A" }]
    },
    "product_market_fit": {
        "brief_overview": [
            { "value": "- **Grand Vision:** A detailed bullet from the pitch deck outlining the company's grand vision, mission, and the core problem it aims to solve.", "sourceType": "pitch_deck", "sourceDetail": "Slide 2: Overview" }
        ],
        "definition_of_tech": [
            { "value": "- **Core Tech:** A verbose, technical bullet explaining a key component of the technology as described in the deck.", "sourceType": "pitch_deck", "sourceDetail": "Slide 6: How It Works" }
        ],
        "problem": [
             { "value": "- **Customer Pain:** A bullet describing the customer pain point, including any quantitative data.", "sourceType": "pitch_deck", "sourceDetail": "Slide 3: The Problem" }
        ],
        "products_being_sold": [
            { "value": "- **Product Offering:** A bullet point describing a product or service offered, including pricing tiers if available.", "sourceType": "pitch_deck", "sourceDetail": "Slide 9: Our Products" }
        ],
        "solution": [
            { "value": "- **Core Solution:** A detailed bullet describing the solution and its value proposition.", "sourceType": "pitch_deck", "sourceDetail": "Slide 4: The Solution" }
        ],
        "unique_selling_point": [
            { "value": "- **USP:** A clear, detailed bullet articulating the USP and moat.", "sourceType": "pitch_deck", "sourceDetail": "Slide 7: Our Edge" }
        ],
        "product_ip_defense": [
            { "value": "- **IP Details:** A detailed bullet describing patents, unique algorithms, or trade secrets.", "sourceType": "pitch_deck", "sourceDetail": "Slide 12: IP" }
        ],
        "target_customer": [
            { "value": "- **ICP:** A detailed Ideal Customer Profile (ICP) bullet point.", "sourceType": "pitch_deck", "sourceDetail": "Slide 8: Target Market" }
        ],
        "market_size": [
            { "value": "- **Company View:** The company's internal TAM, SAM, and SOM analysis from the deck.", "sourceType": "pitch_deck", "sourceDetail": "Slide 5: Market Size" }
        ],
        "history_of_tech_in_india": [
             { "value": "- **Origins:** A detailed bullet point on the history and evolution of this technology or business model within India.", "sourceType": "web_search", "sourceDetail": "URL of historical analysis or report" }
        ]
    },
    "financial_snapshot": {
        "revenue_mrr_arr": [
            { "value": "- **Reported Revenue:** Specific revenue figures, e.g., '$1.2M ARR in FY2024, growing 150% YoY'.", "sourceType": "pitch_deck", "sourceDetail": "Slide 10: Traction" }
        ],
        "use_of_funds": [
            { "value": "- **Allocation Breakdown:** A detailed percentage and dollar breakdown of how the new capital will be allocated.", "sourceType": "pitch_deck", "sourceDetail": "Slide 16: Use of Funds" }
        ]
    },
    "team": {
        "founders": [
          {
            "name": [{ "value": "- **Full Name:** John Doe", "sourceType": "web_search", "sourceDetail": "LinkedIn URL" }],
            "title": [{ "value": "- **Title:** CEO & Co-founder", "sourceType": "pitch_deck", "sourceDetail": "Slide 13" }],
            "background": [
              { "value": "- **Work Experience:** An in-depth background detailing relevant work experience, education, and specific accomplishments.", "sourceType": "pitch_deck", "sourceDetail": "Slide 13: Team" }
            ],
            "linkedin_url": [{ "value": "https://www.linkedin.com/in/profilename", "sourceType": "web_search", "sourceDetail": "LinkedIn" }],
            "other_positions": [
                {
                    "company_name": [{ "value": "- **Company Name:** Other Company Inc.", "sourceType": "web_search", "sourceDetail": "URL to source (e.g., company register, news article)"}],
                    "company_details": [{ "value": "- **Company Details:** A brief summary of what this other company does.", "sourceType": "web_search", "sourceDetail": "URL to other company website"}],
                    "position_held": [{ "value": "- **Position:** Board Member", "sourceType": "web_search", "sourceDetail": "URL to source"}]
                }
            ]
          }
        ],
        "team_gaps": [
            { "value": "- **Leadership Gaps:** A critical analysis of gaps in the current leadership team.", "sourceType": "model_knowledge", "sourceDetail": "Based on team analysis and growth plan" }
        ]
    },
    "competitive_landscape": {
        "key_competitors_summary": [
            { "value": "- **Summary:** A detailed summary of the competitive landscape.", "sourceType": "web_search", "sourceDetail": "URL of competitor analysis article" }
        ]
    },
    "deal_evaluation": {
        "strengths": [
             { "value": "- **Key Strength:** A detailed, evidence-backed bullet point on a deal strength.", "sourceType": "model_knowledge", "sourceDetail": "Synthesized from full analysis" }
        ],
        "risks_concerns": [
            { "value": "- **Key Risk:** A detailed, evidence-backed bullet point on a risk or concern.", "sourceType": "model_knowledge", "sourceDetail": "Synthesized from full analysis" }
        ],
        "potential_failure_points": [
            { "value": "- **Failure Scenario:** A detailed example of how this specific business could fail, supported by analysis. You must provide 2-3 distinct examples here as separate bullet points in this string.", "sourceType": "model_knowledge", "sourceDetail": "Analyst's risk assessment" }
        ],
        "exit_options_ipo": [
             {
                "company_name": [{ "value": "Example IPO Co", "sourceType": "web_search", "sourceDetail": "URL" }],
                "year": [{ "value": "2023", "sourceType": "web_search", "sourceDetail": "URL" }]
            }
        ],
        "exit_options_acquisition": [
            {
                "company_name": [{ "value": "Example Acquired Co", "sourceType": "web_search", "sourceDetail": "URL" }],
                "acquirer": [{ "value": "Big Tech Inc.", "sourceType": "web_search", "sourceDetail": "URL" }],
                "year": [{ "value": "2022", "sourceType": "web_search", "sourceDetail": "URL" }]
            }
        ],
        "exit_options_secondary_sale": [
            {
                "details": [{ "value": "- **Example Sale:** Details about a notable secondary sale in the sector, including involved parties and context.", "sourceType": "web_search", "sourceDetail": "URL" }]
            }
        ],
        "vc_fit": [
            { "value": "- **VC Angle:** An in-depth analysis of the deal's fit with a standard VC portfolio.", "sourceType": "model_knowledge", "sourceDetail": "Based on market trends and VC investment criteria" }
        ],
        "next_action": [
            { "value": "- **Diligence Item:** A specific, actionable due diligence item for the investment team.", "sourceType": "model_knowledge", "sourceDetail": "Based on overall analysis and identified risks" }
        ]
    },
    "legal_analysis": {
        "founder_legal_issues": [
            { "value": "- **Issue Type:** A detailed description of any legal issue found for a founder. If none, state: 'No publicly available information on founder legal issues was found.'", "sourceType": "web_search", "sourceDetail": "URL to court document or news article" }
        ],
        "company_legal_issues": [
            { "value": "- **Case Summary:** A detailed summary of any lawsuit or legal challenge against the company. If none, state: 'No publicly available information on company legal issues was found.'", "sourceType": "web_search", "sourceDetail": "URL to case filing or news report" }
        ]
    }
  }
}
`;
};

/**
 * Sanitizes the raw structured data from the AI to prevent runtime errors.
 * This function ensures that numerical fields are numbers, arrays are arrays,
 * and key objects exist, making the data safe for consumption by React components.
 * @param data The raw data object parsed from the AI's JSON response.
 * @returns A sanitized data object conforming to the StructuredData type.
 */
function sanitizeAnalysisData(data: any): StructuredData {
    if (!data) return data;

    const sanitizeCompetitor = (c: any = {}) => ({
        name: c.name || 'N/A',
        website: c.website || '',
        hq: c.hq || 'N/A',
        founding_year: c.founding_year || 'N/A',
        funding: c.funding || 'N/A',
        fundingAmount: typeof c.fundingAmount === 'string' 
            ? parseFloat(c.fundingAmount.replace(/[^0-9.-]+/g,"")) || 0 
            : c.fundingAmount || 0,
        valuation: c.valuation || 'N/A',
        key_investors: Array.isArray(c.key_investors) ? c.key_investors : [],
        notable_clients: Array.isArray(c.notable_clients) ? c.notable_clients : [],
        recent_moves: c.recent_moves || 'N/A',
        core_product: c.core_product || 'N/A',
        tech_advantage: c.tech_advantage || 'N/A',
        user_co_advantage: c.user_co_advantage || 'N/A',
    });

    const sanitizeChartData = (chart: any) => {
        if (!chart) return { labels: [], datasets: [] };
        chart.labels = Array.isArray(chart.labels) ? chart.labels : [];
        chart.datasets = Array.isArray(chart.datasets) ? chart.datasets : [];
        
        chart.datasets.forEach((dataset: any) => {
            if (dataset && dataset.data) {
                dataset.data = (Array.isArray(dataset.data) ? dataset.data : [])
                    .map((d: any) => {
                        if (d === null) return null; // Preserve nulls for gaps in line charts
                        const num = parseFloat(String(d).replace(/[^0-9.-]+/g,""));
                        return isNaN(num) ? null : num; // Return null if parsing fails, better than 0
                    });
            }
        });
    
        return chart;
    };
    
    const sanitizeSourcedDataArray = (arr: any) => {
        if (Array.isArray(arr) && arr.length > 0) return arr;
        return [{ value: "Information not publicly available", sourceType: "model_knowledge", sourceDetail: "N/A" }];
    };

    data.indian_competitors = Array.isArray(data.indian_competitors) ? data.indian_competitors.map(sanitizeCompetitor) : [];
    data.global_competitors = Array.isArray(data.global_competitors) ? data.global_competitors.map(sanitizeCompetitor) : [];

    data.indian_competitor_chart_data = sanitizeChartData(data.indian_competitor_chart_data);
    data.global_competitor_chart_data = sanitizeChartData(data.global_competitor_chart_data);
    data.market_size_chart_data = sanitizeChartData(data.market_size_chart_data);
    data.market_subcategory_share_chart_data = sanitizeChartData(data.market_subcategory_share_chart_data);
    data.market_subcategory_growth_chart_data = sanitizeChartData(data.market_subcategory_growth_chart_data);

    data.news_articles = Array.isArray(data.news_articles) ? data.news_articles : [];
    data.youtube_videos = Array.isArray(data.youtube_videos) ? data.youtube_videos : [];
    data.research_papers = Array.isArray(data.research_papers) ? data.research_papers : [];
    
    // Sanitize keywords
    data.keywords = data.keywords || { business: [], technical: [] };
    data.keywords.business = Array.isArray(data.keywords.business) ? data.keywords.business : [];
    data.keywords.technical = Array.isArray(data.keywords.technical) ? data.keywords.technical : [];

    // Sanitize structured IC Note fields
    data.market_analysis = sanitizeSourcedDataArray(data.market_analysis);
    data.problem_in_detail = sanitizeSourcedDataArray(data.problem_in_detail);
    data.solution_in_detail = sanitizeSourcedDataArray(data.solution_in_detail);
    data.products_analysis = sanitizeSourcedDataArray(data.products_analysis);
    data.pictorial_technology_definition = sanitizeSourcedDataArray(data.pictorial_technology_definition);
    data.usp_moat = sanitizeSourcedDataArray(data.usp_moat);
    data.ip_summary = sanitizeSourcedDataArray(data.ip_summary);
    data.competition_summary = sanitizeSourcedDataArray(data.competition_summary);
    data.traction_summary = sanitizeSourcedDataArray(data.traction_summary);
    data.business_model = sanitizeSourcedDataArray(data.business_model);
    data.team_summary = sanitizeSourcedDataArray(data.team_summary);
    data.fundraises_summary = sanitizeSourcedDataArray(data.fundraises_summary);
    data.investment_required = sanitizeSourcedDataArray(data.investment_required);
    data.use_of_investments = sanitizeSourcedDataArray(data.use_of_investments);
    data.financial_plan_summary = sanitizeSourcedDataArray(data.financial_plan_summary);
    data.expert_opinion = sanitizeSourcedDataArray(data.expert_opinion);
    data.exit_plan_summary = sanitizeSourcedDataArray(data.exit_plan_summary);
    data.investment_risk = sanitizeSourcedDataArray(data.investment_risk);
    data.investment_rationale = sanitizeSourcedDataArray(data.investment_rationale);
    data.conclusion = sanitizeSourcedDataArray(data.conclusion);
    data.future_roadmap = sanitizeSourcedDataArray(data.future_roadmap);
    
    // Sanitize Financial Projections
    data.financial_projections = data.financial_projections || { headers: [], rows: [], source: { sourceType: 'model_knowledge', sourceDetail: 'N/A' } };
    data.financial_projections.headers = Array.isArray(data.financial_projections.headers) ? data.financial_projections.headers : [];
    data.financial_projections.rows = (Array.isArray(data.financial_projections.rows) ? data.financial_projections.rows : []).map((row: any) => {
        if (!row) return null;
        return {
            metric: row.metric || 'N/A',
            values: (Array.isArray(row.values) ? row.values : []).map((v: any) => {
                if (v === null) return null;
                const num = parseFloat(String(v).replace(/[^0-9.-]+/g, ""));
                return isNaN(num) ? null : num;
            })
        };
    }).filter(Boolean);


    // Ensure executive summary data and its nested properties exist to prevent crashes
    data.executiveSummaryData = data.executiveSummaryData || {};
    
    data.executiveSummaryData.product_market_fit = data.executiveSummaryData.product_market_fit || {};
    data.executiveSummaryData.product_market_fit.history_of_tech_in_india = sanitizeSourcedDataArray(data.executiveSummaryData.product_market_fit.history_of_tech_in_india);
    
    data.executiveSummaryData.deal_evaluation = data.executiveSummaryData.deal_evaluation || {};
    data.executiveSummaryData.deal_evaluation.potential_failure_points = sanitizeSourcedDataArray(data.executiveSummaryData.deal_evaluation.potential_failure_points);
    
    data.executiveSummaryData.deal_evaluation.exit_options_ipo = (Array.isArray(data.executiveSummaryData.deal_evaluation.exit_options_ipo) ? data.executiveSummaryData.deal_evaluation.exit_options_ipo : []).map((ipo) => {
        if (!ipo) return null;
        return {
            company_name: sanitizeSourcedDataArray(ipo.company_name),
            year: sanitizeSourcedDataArray(ipo.year),
        };
    }).filter(Boolean);
    
    data.executiveSummaryData.deal_evaluation.exit_options_acquisition = (Array.isArray(data.executiveSummaryData.deal_evaluation.exit_options_acquisition) ? data.executiveSummaryData.deal_evaluation.exit_options_acquisition : []).map((acq) => {
        if (!acq) return null;
        return {
            company_name: sanitizeSourcedDataArray(acq.company_name),
            acquirer: sanitizeSourcedDataArray(acq.acquirer),
            year: sanitizeSourcedDataArray(acq.year),
        };
    }).filter(Boolean);
    
    data.executiveSummaryData.deal_evaluation.exit_options_secondary_sale = (Array.isArray(data.executiveSummaryData.deal_evaluation.exit_options_secondary_sale) ? data.executiveSummaryData.deal_evaluation.exit_options_secondary_sale : []).map((sale) => {
        if (!sale) return null;
        return {
            details: sanitizeSourcedDataArray(sale.details),
        };
    }).filter(Boolean);

    
    data.executiveSummaryData.team = data.executiveSummaryData.team || { founders: [], team_gaps: [] };
    data.executiveSummaryData.team.founders = (Array.isArray(data.executiveSummaryData.team.founders) 
        ? data.executiveSummaryData.team.founders 
        : []
    ).map((founder: any) => {
        if (!founder) return null;
        founder.name = sanitizeSourcedDataArray(founder.name);
        founder.title = sanitizeSourcedDataArray(founder.title);
        founder.background = sanitizeSourcedDataArray(founder.background);
        founder.linkedin_url = sanitizeSourcedDataArray(founder.linkedin_url);
        founder.other_positions = (Array.isArray(founder.other_positions) ? founder.other_positions : []).map((pos: any) => {
            if (!pos) return null;
            return {
                company_name: sanitizeSourcedDataArray(pos.company_name),
                company_details: sanitizeSourcedDataArray(pos.company_details),
                position_held: sanitizeSourcedDataArray(pos.position_held),
            };
        }).filter(Boolean); // remove nulls
        return founder;
    }).filter(Boolean); // remove nulls
      
    // Sanitize legal analysis data
    data.executiveSummaryData.legal_analysis = data.executiveSummaryData.legal_analysis || { founder_legal_issues: [], company_legal_issues: [] };
    data.executiveSummaryData.legal_analysis.founder_legal_issues = sanitizeSourcedDataArray(data.executiveSummaryData.legal_analysis.founder_legal_issues);
    data.executiveSummaryData.legal_analysis.company_legal_issues = sanitizeSourcedDataArray(data.executiveSummaryData.legal_analysis.company_legal_issues);
        
    return data as StructuredData;
}


export async function generateComprehensiveAnalysis(
    companyName: string, 
    companyWebsite: string, 
    file: File | null, 
    onProgress: (message: string) => void
): Promise<AnalysisResult> {
    
    // Progress starts after file download, so we start it higher
    onProgress('10');
    const parts: any[] = [{ text: getAnalysisPrompt(companyName, companyWebsite, !!file) }];

    if (file) {
        const onPdfProgress = (progress: number) => {
            // PDF conversion is from 10% to 40%
            onProgress(String(10 + Math.round(progress * 30)));
        };
        const base64Images = await convertPdfToImages(file, onPdfProgress);
        const imageParts = base64Images.map(img => ({
            inlineData: { mimeType: 'image/jpeg', data: img },
        }));
        parts.push(...imageParts);
    }

    onProgress('45');
    
    const response = await generateContentWithRetry({
        model: "gemini-2.5-flash",
        contents: { parts },
        config: {
            tools: [{ googleSearch: {} }],
            temperature: 0.5,
        },
    });

    onProgress('90');

    // Defensive check for blocked or empty responses
    if (!response.text) {
        const blockReason = response.candidates?.[0]?.finishReason;
        const safetyRatings = response.candidates?.[0]?.safetyRatings;
        let errorDetails = 'The AI response was empty or malformed.';
        if (blockReason === 'SAFETY') {
            const blockedCategories = safetyRatings?.filter(r => r.probability !== 'NEGLIGIBLE').map(r => r.category.replace('HARM_CATEGORY_', '')).join(', ');
            errorDetails = `The response was blocked for safety reasons. Affected categories: ${blockedCategories || 'Not specified'}.`;
        } else if (blockReason) {
             errorDetails = `The response was incomplete. Reason: ${blockReason}.`;
        }
        throw new Error(`Analysis failed: ${errorDetails} Please try again or adjust your input.`);
    }

    let fullText = response.text;
    let markdownReport = fullText;
    let structuredData: any = null;

    const groundingMetadata = response.candidates?.[0]?.groundingMetadata;
    const sources: { uri: string; title: string }[] = groundingMetadata?.groundingChunks?.reduce<{ uri: string; title: string }[]>((acc, chunk) => {
        if (chunk.web?.uri && !acc.some(s => s.uri === chunk.web.uri)) {
            acc.push({
                uri: chunk.web.uri,
                title: chunk.web.title || chunk.web.uri,
            });
        }
        return acc;
    }, []) || [];
    
    const jsonRegex = /```json\s*([\s\S]*?)\s*```/s;
    const jsonMatch = fullText.match(jsonRegex);
    let jsonString: string | null = null;

    if (jsonMatch && jsonMatch[1]) {
        jsonString = jsonMatch[1];
        markdownReport = fullText.replace(jsonRegex, '').trim();
    } else {
        // Fallback for cases where markdown fence is missing
        const part2Marker = 'PART 2: JSON DATA';
        const part2Index = fullText.lastIndexOf(part2Marker);
        if (part2Index !== -1) {
            console.warn("Could not find ```json block. Attempting fallback using 'PART 2' marker.");
            const potentialJson = fullText.substring(part2Index);
            const jsonStartIndex = potentialJson.indexOf('{');
            if (jsonStartIndex !== -1) {
                jsonString = potentialJson.substring(jsonStartIndex);
                markdownReport = fullText.substring(0, part2Index).trim();
            }
        }
    }
    
    if (jsonString) {
        try {
            // First, try to parse the original string. This will succeed for well-formed JSON.
            structuredData = JSON.parse(jsonString);
        } catch (e) {
            console.warn("Initial JSON parsing failed. Attempting to repair. Error:", (e as Error).message);
            // This repair logic attempts to fix common LLM JSON errors like comments,
            // trailing commas, and truncation.
            let repairedJson = jsonString
                // 1. Remove single-line and multi-line comments.
                .replace(/\/\*[\s\S]*?\*\/|^\s*\/\/.*$/gm, '')
                .trim();
            
            // 2. Remove trailing commas from objects and arrays.
            repairedJson = repairedJson.replace(/,(?=\s*[}\]])/g, '');
            
            // 3. Handle potential truncation by attempting to close open structures.
            // This is a heuristic and might not work for all cases.
            const openBraces = (repairedJson.match(/{/g) || []).length;
            const closeBraces = (repairedJson.match(/}/g) || []).length;
            if (openBraces > closeBraces) {
                repairedJson += '}'.repeat(openBraces - closeBraces);
            }

            const openBrackets = (repairedJson.match(/\[/g) || []).length;
            const closeBrackets = (repairedJson.match(/]/g) || []).length;
            if (openBrackets > closeBrackets) {
                repairedJson += ']'.repeat(openBrackets - closeBrackets);
            }

            // 4. One final pass to remove trailing commas that might have appeared after closing brackets.
             repairedJson = repairedJson.replace(/,(?=\s*[}\]])/g, '');

            try {
                // Try parsing the repaired string.
                structuredData = JSON.parse(repairedJson);
                console.log("Successfully parsed JSON after repair attempts.");
            } catch (finalError) {
                // If even the repaired string fails to parse, we give up.
                console.error("Failed to parse JSON even after repair attempts:", (finalError as Error).message);
                // Log the problematic strings for debugging.
                console.error("Original problematic JSON string:", jsonString);
                console.error("Repaired JSON string that failed:", repairedJson);
                structuredData = null; // Mark as failed.
            }
        }
    }
    
    // If we failed to extract or parse the JSON, throw a clear error.
    if (!structuredData) {
        throw new Error(`Failed to extract structured data from the AI's response. The response may be incomplete or malformed. Please try again.`);
    }

    // Sanitize data to prevent component crashes
    structuredData = sanitizeAnalysisData(structuredData);
    
    // Check for a pitch deck summary if a deck was provided
    let pitchDeckSummary = null;
    if (file) {
        onProgress('95');
        const summaryResponse = await generateContentWithRetry({
             model: 'gemini-2.5-flash',
             contents: { parts: [
                {text: "Summarize the key points of this pitch deck in 3-5 bullet points."},
                ...parts.filter(p => p.inlineData)
             ]},
        });
        pitchDeckSummary = summaryResponse.text;
    }


    onProgress('100');
    return { markdownReport, structuredData, sources, pitchDeckSummary };
}

export function createChat(reportContext: string, deckContext: string | null): Chat {
    const systemInstruction = `You are an expert AI investment analyst assistant. The user has just received an analysis report for a startup. Your task is to answer their follow-up questions based on the provided context.

Context from the main report:
---
${reportContext.substring(0, 3000)}...
---
${deckContext ? `Context from the pitch deck summary:\n---\n${deckContext}\n---\n` : ''}
Be concise and helpful. If the answer isn't in the context, say so and offer to search for it if the user agrees.`;

    const chat = ai.chats.create({
        model: 'gemini-2.5-flash',
        config: { systemInstruction },
        history: [],
    });
    return chat;
}