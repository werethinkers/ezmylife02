

import React, { useState, useCallback, useEffect, useRef, useMemo } from 'react';
import { generateComprehensiveAnalysis, createChat, fetchCompanies, fetchPitchDeckAsFile } from './services/geminiService';
import { BrainCircuitIcon, ClipboardDocumentListIcon, DocumentTextIcon, GlobeAltIcon, PaperAirplaneIcon, SparklesIcon, XIcon, DownloadIcon, TableCellsIcon, BuildingOfficeIcon, UsersIcon, CurrencyDollarIcon, RocketLaunchIcon, BookOpenIcon, PencilSquareIcon, DocumentDuplicateIcon, ClipboardDocumentCheckIcon, LightBulbIcon, ScaleIcon } from './components/icons';
import type { AnalysisResult, ChatMessage, Competitor, FounderDetail, ResourceItem, SourcedDataPoint, Company } from './types';
import type { Chat } from '@google/genai';
import { CompetitorChart } from './components/CompetitorChart';
import { prompts } from './constants';
import { PromptSelector } from './components/PromptSelector';
import { ExecutiveSummary } from './components/ExecutiveSummary';
import { Resources } from './components/Resources';
import { TeamDisplay } from './components/TeamDisplay';
import { LegalAnalysis } from './components/LegalAnalysis';
import { ICNote } from './components/ICNote';
import { FileUploader } from './components/FileUploader';
import { EditableContent, highlightText } from './components/EditableContent';
import { FinancialProjectionsTable } from './components/FinancialProjectionsTable';
import { MermaidDiagram } from './components/MermaidDiagram';

// Make docx and FileSaver available on the window object
declare global {
    interface Window {
        docx: any;
        saveAs: any;
        showdown: any;
        mermaid: any;
    }
}

type AppStep = 'input' | 'analyzing' | 'results' | 'error';
type ResultTab = 'all' | 'executiveSummary' | 'report' | 'data' | 'resources' | 'legal' | 'chat' | 'download';
type InputMethod = 'database' | 'manual';

// Helper for deep-updates on state
const updateNestedState = (prevState: any, path: (string | number)[], value: any) => {
    const newState = structuredClone(prevState);
    let current = newState;
    for (let i = 0; i < path.length - 1; i++) {
        current = current[path[i]];
        if (current === undefined || current === null) {
            return prevState; // Path is invalid, return original state
        }
    }
    current[path[path.length - 1]] = value;
    return newState;
};


// Helper functions for URL manipulation
const getDomainFromUrl = (url: string): string => {
    if (!url) return '';
    try {
        let fullUrl = url.trim();
        if (!/^(https?)/.test(fullUrl)) {
            fullUrl = `https://${fullUrl}`;
        }
        return new URL(fullUrl).hostname;
    } catch (e) {
        const domainMatch = url.match(/^(?:https?:\/\/)?(?:www\.)?([^/]+)/);
        return domainMatch ? domainMatch[1] : url;
    }
};

const normalizeUrl = (url: string): string => {
    if (!url) return '#';
    const trimmedUrl = url.trim();
    if (!/^(https?:|ftp:)/.test(trimmedUrl)) {
        return `https://${trimmedUrl}`;
    }
    return trimmedUrl;
};

const CompetitorCard = ({ competitor, path, onUpdate, keywords, highlightEnabled }: { competitor: Competitor, path: (string | number)[], onUpdate: (path: (string|number)[], value: any) => void, keywords: string[], highlightEnabled: boolean }) => {
    const domain = getDomainFromUrl(competitor.website);
    
    const renderField = (label: string, field: keyof Competitor, as: 'input' | 'textarea' = 'input') => (
        <div className="grid grid-cols-3 gap-2 items-start">
            <span className="font-semibold text-gray-600 col-span-1 pt-2">{label}:</span>
            <div className="col-span-2">
                 <EditableContent 
                    value={competitor[field] as string}
                    onUpdate={(val) => onUpdate([...path, field], field === 'key_investors' ? (val as string).split(',').map(s=>s.trim()) : val)}
                    keywords={keywords}
                    highlightEnabled={highlightEnabled}
                    as={as}
                 />
            </div>
        </div>
    );
    
    return (
        <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-200 flex flex-col h-full page-break-avoid">
            <div className="flex items-center gap-4 mb-4">
                <img src={`https://www.google.com/s2/favicons?domain=${domain}&sz=64`} alt={`${competitor.name} logo`} className="w-10 h-10 rounded-full object-contain border" />
                <div className="font-bold text-lg text-gray-800 flex-grow">
                    <EditableContent 
                        value={competitor.name}
                        onUpdate={(val) => onUpdate([...path, 'name'], val)}
                        keywords={keywords}
                        highlightEnabled={highlightEnabled}
                        placeholder="Competitor Name"
                    />
                </div>
            </div>

            <div className="grid grid-cols-2 gap-4 mb-4 border-y border-gray-200 py-3">
                <div className="text-center">
                    <div className="flex items-center justify-center gap-1.5 text-sm font-medium text-gray-500 mb-1">
                        <CurrencyDollarIcon className="w-5 h-5 text-green-500" />
                        <span>Funding</span>
                    </div>
                    <div className="text-lg font-semibold text-gray-800">
                        <EditableContent 
                            value={competitor.funding}
                            onUpdate={(val) => onUpdate([...path, 'funding'], val)}
                            keywords={keywords}
                            highlightEnabled={highlightEnabled}
                            placeholder="e.g., $50M"
                        />
                    </div>
                </div>
                <div className="text-center">
                    <div className="flex items-center justify-center gap-1.5 text-sm font-medium text-gray-500 mb-1">
                        <ScaleIcon className="w-5 h-5 text-indigo-500" />
                        <span>Valuation</span>
                    </div>
                    <div className="text-lg font-semibold text-gray-800">
                        <EditableContent 
                            value={competitor.valuation}
                            onUpdate={(val) => onUpdate([...path, 'valuation'], val)}
                            keywords={keywords}
                            highlightEnabled={highlightEnabled}
                            placeholder="e.g., $500M"
                        />
                    </div>
                </div>
            </div>
            
            <div className="space-y-1">
                {renderField("Website", "website")}
                {renderField("HQ", "hq")}
                {renderField("Founding Year", "founding_year")}
                {renderField("Key Investors", "key_investors")}
                {renderField("Core Product", "core_product", "textarea")}
                {renderField("Tech Advantage", "tech_advantage", "textarea")}
                {renderField("Our Advantage", "user_co_advantage", "textarea")}
            </div>
        </div>
    );
};

const NewsSnippetCard = ({ article }: { article: ResourceItem }) => (
    <div className="border-t border-gray-200 pt-3 mt-3 first:mt-0 first:border-t-0 first:pt-0">
        <a href={normalizeUrl(article.url)} target="_blank" rel="noopener noreferrer" className="font-semibold text-blue-600 hover:underline text-sm break-words">
            {article.title}
        </a>
        <p className="text-xs text-gray-500 mt-1">{article.summary}</p>
    </div>
);

export default function App(): React.ReactNode {
  const [step, setStep] = useState<AppStep>('input');
  const [companies, setCompanies] = useState<Company[]>([]);
  const [isLoadingCompanies, setIsLoadingCompanies] = useState(true);
  const [analysisResult, setAnalysisResult] = useState<AnalysisResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [progressMessage, setProgressMessage] = useState<string>('');

  // State for input screen
  const [inputMethod, setInputMethod] = useState<InputMethod>('database');
  const [selectedCompanyId, setSelectedCompanyId] = useState<string>('');
  const [manualCompanyName, setManualCompanyName] = useState('');
  const [manualCompanyWebsite, setManualCompanyWebsite] = useState('');
  const [manualPitchDeck, setManualPitchDeck] = useState<File | null>(null);
  
  // State for results view
  const [activeTab, setActiveTab] = useState<ResultTab>('all');
  const [chat, setChat] = useState<Chat | null>(null);
  const [chatHistory, setChatHistory] = useState<ChatMessage[]>([]);
  const [chatInput, setChatInput] = useState('');
  const [isChatting, setIsChatting] = useState(false);
  const chatContainerRef = useRef<HTMLDivElement>(null);
  const [rawJsonError, setRawJsonError] = useState<string | null>(null);
  const [copyStatus, setCopyStatus] = useState<'idle' | 'copied_for_gdoc'>('idle');

  // State for download tab
  const [downloadableHtml, setDownloadableHtml] = useState('');
  const [isGeneratingDownload, setIsGeneratingDownload] = useState(false);
  const [highlightEnabled, setHighlightEnabled] = useState(true);
  
  useEffect(() => {
    const loadCompanies = async () => {
      try {
        const companyData = await fetchCompanies();
        setCompanies(companyData);
      } catch (e: any) {
        setError(e.message || 'Failed to load companies from Google Sheet.');
      } finally {
        setIsLoadingCompanies(false);
      }
    };
    loadCompanies();
  }, []);

  const allKeywords = useMemo(() => {
      if (!analysisResult?.structuredData?.keywords) return [];
      const { business = [], technical = [] } = analysisResult.structuredData.keywords;
      // Filter out empty strings and sort by length descending for better matching
      return [...new Set([...business, ...technical])]
          .filter(k => k && k.length > 1)
          .sort((a, b) => b.length - a.length);
  }, [analysisResult?.structuredData?.keywords]);

    const generateDownloadableHtml = useCallback(async (): Promise<string> => {
        if (!analysisResult || !analysisResult.structuredData) return '';

        const { structuredData, markdownReport } = analysisResult;
        const contentWrapper = document.getElementById('all-content-wrapper');
        if (!contentWrapper) return '';
        
        const clonedContent = contentWrapper.cloneNode(true) as HTMLElement;
        
        clonedContent.querySelectorAll('.no-download').forEach(el => el.remove());
        
        // Remove the IC Note from 'all-in-one' view for download, and replace it with a container.
        // The script will now inject the full ICNote component's content, which is already structured.
        const icNoteSection = clonedContent.querySelector('#all-report-container');
        if (icNoteSection) {
            // Replace with a clean container that will be populated by the live, editable ICNote view
            icNoteSection.innerHTML = `
                <section id="all-report" class="page-break-before">
                    <!-- The full IC Note component will be rendered here from the main content -->
                </section>
            `;
            const liveIcNote = clonedContent.querySelector('#ic-note-live-content');
            if (liveIcNote) {
              icNoteSection.querySelector('#all-report')?.appendChild(liveIcNote.cloneNode(true));
            }
             clonedContent.querySelector('#ic-note-live-content')?.remove();
        }
        
        // --- Chart Handling ---
        const chartDefinitionsForDownload = [
            { containerId: 'chart-indian-funding', canvasId: 'canvas-indian-funding' },
            { containerId: 'chart-global-funding', canvasId: 'canvas-global-funding' },
            { containerId: 'chart-market-size', canvasId: 'canvas-market-size' },
            { containerId: 'chart-market-share', canvasId: 'canvas-market-share' },
            { containerId: 'chart-market-growth', canvasId: 'canvas-market-growth' },
        ];

        chartDefinitionsForDownload.forEach(def => {
            const container = clonedContent.querySelector(`#${def.containerId}`);
            if (container) {
                // Replace the React-rendered chart component with a simple canvas element.
                // The script in the downloaded HTML will find this canvas by its ID and draw the chart.
                container.innerHTML = `<div class="relative h-96 w-full"><canvas id="${def.canvasId}"></canvas></div>`;
            }
        });

        // --- Assign unique IDs for auto-saving ---
        let editableCounter = 0;
        const getUniqueId = () => `editable-${editableCounter++}`;

        clonedContent.querySelectorAll('[data-is-editable="true"]').forEach((el) => {
            el.setAttribute('data-editable-id', getUniqueId());
        });
        
        const pageTitle = `Startup Analysis: ${structuredData.name}`;

        const finalScript = `
        function manageEditableContent() {
            const storageKey = 'saved_content_' + \`${structuredData.name.replace(/\s/g, '_')}\`;

            // Function to save content
            const saveContent = () => {
                try {
                    const savedData = localStorage.getItem(storageKey) || '{}';
                    const currentData = JSON.parse(savedData);
                    document.querySelectorAll('[data-editable-id]').forEach(el => {
                        const id = el.dataset.editableId;
                        if (id) currentData[id] = el.innerHTML;
                    });
                    localStorage.setItem(storageKey, JSON.stringify(currentData));
                } catch (e) { console.error('Failed to save content:', e); }
            };

            // Load saved content from localStorage
            try {
                const savedData = localStorage.getItem(storageKey);
                if (savedData) {
                    const parsedData = JSON.parse(savedData);
                    Object.keys(parsedData).forEach(id => {
                        const el = document.querySelector(\`[data-editable-id="\${id}"]\`);
                        if (el) el.innerHTML = parsedData[id];
                    });
                }
            } catch (e) {
                console.error('Failed to load saved content:', e);
            }

            // Save content on blur
            document.body.addEventListener('blur', (event) => {
                if (event.target && event.target.hasAttribute('data-editable-id')) {
                    saveContent();
                }
            }, true); // Use capturing to catch all blur events

            // Make elements editable
            document.querySelectorAll('[data-editable-id]').forEach(el => {
                el.setAttribute('contenteditable', 'true');
            });
        }
        
        function initializeCharts() {
            const chartData = ${JSON.stringify({
                indian_funding: structuredData.indian_competitor_chart_data,
                global_funding: structuredData.global_competitor_chart_data,
                market_size: structuredData.market_size_chart_data,
                market_share: structuredData.market_subcategory_share_chart_data,
                market_growth: structuredData.market_subcategory_growth_chart_data,
            })};

            const getChartOptions = (type, title) => {
                const options = {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: { position: 'top' },
                        title: { display: true, text: title, font: { size: 16 } },
                    },
                };
                if (type === 'bar' || type === 'line') {
                    options.scales = {
                        y: {
                            beginAtZero: true,
                            ticks: {
                                callback: function(value) {
                                    if (typeof value === 'number') {
                                        if (value >= 1000000000) return '$' + (value / 1000000000) + 'B';
                                        if (value >= 1000000) return '$' + (value / 1000000) + 'M';
                                        if (value >= 1000) return '$' + (value / 1000) + 'K';
                                        return '$' + value;
                                    }
                                    return value;
                                }
                            }
                        }
                    };
                }
                if (type === 'pie' || type === 'donut') {
                    if(!options.plugins.tooltip) options.plugins.tooltip = {};
                     if(!options.plugins.tooltip.callbacks) options.plugins.tooltip.callbacks = {};
                    options.plugins.tooltip.callbacks.label = function(context) {
                        let label = context.label || '';
                        if (label) { label += ': '; }
                        if (context.parsed !== null) {
                            const total = context.chart.data.datasets[0].data.reduce((a, b) => a + b, 0);
                            const percentage = total > 0 ? (context.parsed / total * 100).toFixed(2) : 0;
                            label += context.raw + ' (' + percentage + '%)';
                        }
                        return label;
                    };
                }
                return options;
            };

            const chartDefinitions = [
                { canvasId: 'canvas-indian-funding', dataKey: 'indian_funding', title: 'Funding Comparison (Indian)' },
                { canvasId: 'canvas-global-funding', dataKey: 'global_funding', title: 'Funding Comparison (Global)' },
                { canvasId: 'canvas-market-size', dataKey: 'market_size', title: 'Market Size Projection (USD Billions)' },
                { canvasId: 'canvas-market-share', dataKey: 'market_share', title: 'Market Share by Subcategory (%)' },
                { canvasId: 'canvas-market-growth', dataKey: 'market_growth', title: 'Subcategory Growth (USD Billions)' },
            ];

            chartDefinitions.forEach(def => {
                const data = chartData[def.dataKey];
                const canvas = document.getElementById(def.canvasId);
                if (canvas && data && data.datasets && data.datasets.some(ds => ds.data && ds.data.length > 0)) {
                    const ctx = canvas.getContext('2d');
                    if (ctx) {
                        new window.Chart(ctx, {
                            type: data.type || 'bar',
                            data: data,
                            options: getChartOptions(data.type, def.title)
                        });
                    }
                }
            });
        }

        window.addEventListener('load', () => {
            mermaid.initialize({ startOnLoad: false, theme: 'neutral' });
            initializeCharts();
            manageEditableContent();
            setTimeout(() => {
                if (window.mermaid) {
                    const unprocessedMermaidNodes = document.querySelectorAll('.mermaid:not([data-processed="true"])');
                    if (unprocessedMermaidNodes.length > 0) {
                        window.mermaid.run({ nodes: unprocessedMermaidNodes });
                    }
                }
            }, 200);
        });
    `;

        const editCss = `
        [contenteditable="true"], [data-editable-id] {
            cursor: text;
            transition: box-shadow 0.2s, background-color 0.2s;
        }
        [contenteditable="true"]:hover, [data-editable-id]:hover {
            background-color: #fefce8; /* yellow-50 */
        }
        [contenteditable="true"]:focus, [data-editable-id]:focus {
            outline: 2px solid #3b82f6; /* blue-500 */
            box-shadow: 0 0 0 4px rgba(59, 130, 246, 0.2);
            background-color: #eff6ff; /* blue-50 */
        }
        mark {
            background-color: #fef08a; /* yellow-300 */
            padding: 2px 4px;
            border-radius: 3px;
        }
        .page-break-avoid { break-inside: avoid; }
        .page-break-before { break-before: page; }
        .page-break-after { break-after: page; }
        
        @media print {
            body { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
            .no-print { display: none !important; }
            [contenteditable="true"], [data-editable-id] {
                outline: none !important;
                background-color: transparent !important;
                box-shadow: none !important;
            }
            main { box-shadow: none !important; border: none !important; margin: 0 !important; padding: 0 !important; }
        }
    `;

        return `
      <!DOCTYPE html>
      <html lang="en">
        <head>
          <meta charset="UTF-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>${pageTitle}</title>
          <script src="https://cdn.tailwindcss.com"></script>
          <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
          <script src="https://cdnjs.cloudflare.com/ajax/libs/showdown/2.1.0/showdown.min.js"></script>
          <script src="https://cdn.jsdelivr.net/npm/mermaid@10/dist/mermaid.min.js"></script>
          <style>
             body { background-color: #f3f4f6; font-family: sans-serif; }
             main { 
                margin: 2rem auto; 
                max-width: 1024px; 
                background: white; 
                padding: 2rem; 
                border-radius: 0.75rem;
                box-shadow: 0 10px 15px -3px rgb(0 0 0 / 0.1), 0 4px 6px -4px rgb(0 0 0 / 0.1);
             }
             h1, h2, h3, h4, h5, h6 { page-break-after: avoid; }
             div, section, table, figure { page-break-inside: avoid; }
             section { padding-top: 2rem !important; margin-top: 2rem !important; border-top: 1px solid #ddd; }
             section:first-child { border-top: none; padding-top: 0; margin-top: 0; }
             a { color: #3b82f6; text-decoration: none; }
             a:hover { text-decoration: underline; }
             .mermaid svg { margin: auto; }
             .prose { max-width: none; }
             ${editCss}
          </style>
        </head>
        <body>
          <main class="p-4 sm:p-8">
            <h1 class="text-3xl sm:text-4xl font-bold text-center mb-12 text-gray-900">${pageTitle}</h1>
            ${clonedContent.innerHTML}
          </main>
          <script>
            ${finalScript}
          </script>
        </body>
      </html>`;
    }, [analysisResult]);

  useEffect(() => {
    // This effect handles rendering for any mermaid diagrams present in the current view
    if (analysisResult && window.mermaid) {
        setTimeout(async () => {
            const unprocessedElements = document.querySelectorAll('.mermaid:not([data-processed="true"])');
            if (unprocessedElements.length === 0) return;

            for (const el of Array.from(unprocessedElements)) {
                const element = el as HTMLElement;
                let definition = (element.textContent || '').trim();

                if (!definition) {
                    element.setAttribute('data-processed', 'true');
                    continue;
                }
                
                try {
                    // Attempt to clean up common syntax errors from the model, like semicolons.
                    definition = definition.replace(/;/g, '\n');
                    element.textContent = definition;

                    await window.mermaid.run({ nodes: [element] });
                } catch (e: any) {
                    console.error("Mermaid rendering failed for definition:", definition, e.message, e);
                    element.innerHTML = `
                        <div class="p-4 bg-red-50 border border-red-200 rounded-lg text-red-700 text-left">
                            <p class="font-bold">Diagram Rendering Failed</p>
                            <p class="text-sm mb-2">The AI may have generated invalid syntax.</p>
                            <details class="text-xs mt-2">
                                <summary>Show Diagram Code</summary>
                                <pre class="mt-2 font-mono bg-red-100 p-2 rounded whitespace-pre-wrap break-all">${definition}</pre>
                            </details>
                        </div>
                    `;
                    // Mark as processed even on failure to avoid loops
                    element.setAttribute('data-processed', 'true');
                }
            }
        }, 100);
    }
  }, [activeTab, analysisResult]);


  useEffect(() => {
    chatContainerRef.current?.scrollTo(0, chatContainerRef.current.scrollHeight);
  }, [chatHistory]);

  // Effect to handle generation of the downloadable HTML file
  useEffect(() => {
      if (activeTab === 'download' && !downloadableHtml && !isGeneratingDownload && analysisResult) {
          const prepare = async () => {
              setIsGeneratingDownload(true);
              // Wait a moment for React to render the hidden AllInOneView
              await new Promise(resolve => setTimeout(resolve, 100)); 
              try {
                  const html = await generateDownloadableHtml();
                  setDownloadableHtml(html);
              } catch (e) {
                  console.error("Failed to generate download HTML", e);
                  setError("Could not prepare the download file. Please try again.");
              } finally {
                  setIsGeneratingDownload(false);
              }
          };
          prepare();
      }
  }, [activeTab, downloadableHtml, isGeneratingDownload, analysisResult, generateDownloadableHtml]);

  const handleDataChange = useCallback((path: (string | number)[], value: any) => {
    setAnalysisResult(prev => {
        if (!prev) return null;
        // When data changes, invalidate the downloadable HTML so it can be regenerated
        setDownloadableHtml('');
        return updateNestedState(prev, path, value);
    });
  }, []);

  const handleRawJsonChange = (jsonString: string) => {
    try {
        const parsed = JSON.parse(jsonString);
        handleDataChange(['structuredData'], parsed);
        setRawJsonError(null);
    } catch (e: any) {
        setRawJsonError(`Invalid JSON: ${e.message}`);
    }
  };

  const handleStartAnalysis = useCallback(async () => {
    let companyName: string;
    let companyWebsite: string;
    let pitchDeckFile: File | null = null;
    
    setStep('analyzing');
    setError(null);

    if (inputMethod === 'manual') {
        if (!manualCompanyName || !manualCompanyWebsite) {
            setError('Please provide a company name and website.');
            setStep('input');
            return;
        }
        companyName = manualCompanyName;
        companyWebsite = manualCompanyWebsite;
        pitchDeckFile = manualPitchDeck;
        setProgressMessage('10');
    } else { // 'database'
        const selectedCompany = companies.find(c => c.name === selectedCompanyId);
        if (!selectedCompany) {
          setError('Please select a company.');
          setStep('input');
          return;
        }
        companyName = selectedCompany.name;
        companyWebsite = selectedCompany.website;
        
        try {
            setProgressMessage('5');
            pitchDeckFile = await fetchPitchDeckAsFile(selectedCompany.pitchDeckUrl);
            setProgressMessage('10');
        } catch (e: any) {
            setError(e.message || 'Failed to download pitch deck.');
            setStep('error');
            return;
        }
    }

    try {
      const result = await generateComprehensiveAnalysis(
          companyName, 
          companyWebsite, 
          pitchDeckFile, 
          setProgressMessage
      );

      setAnalysisResult(result);
      
      const newChat = createChat(result.markdownReport, result.pitchDeckSummary);
      setChat(newChat);
      setChatHistory([]);
      
      setStep('results');
      setActiveTab('all');
    } catch (e: unknown) {
      const errorMessage = e instanceof Error ? e.message : 'An unknown error occurred.';
      setError(errorMessage.replace(/^Error:\s*/, ''));
      setStep('error');
    } finally {
      setProgressMessage('');
    }
  }, [
    selectedCompanyId, 
    companies, 
    inputMethod, 
    manualCompanyName, 
    manualCompanyWebsite, 
    manualPitchDeck
  ]);

  const handleStartOver = () => {
    setStep('input');
    setSelectedCompanyId('');
    setAnalysisResult(null);
    setError(null);
    setProgressMessage('');
    setActiveTab('all');
    setChat(null);
    setChatHistory([]);
    setChatInput('');
    setDownloadableHtml('');
    setIsGeneratingDownload(false);
    setInputMethod('database');
    setManualCompanyName('');
    setManualCompanyWebsite('');
    setManualPitchDeck(null);
  };

  const handleSendMessage = async () => {
    if (!chatInput.trim() || !chat || isChatting) return;

    setIsChatting(true);
    const text = chatInput;
    const userMessage: ChatMessage = { role: 'user', parts: [{ text }] };
    setChatHistory(prev => [...prev, userMessage]);
    setChatInput('');

    try {
      const stream = await chat.sendMessageStream({ message: text });
      let fullResponse = "";
      let modelMessage: ChatMessage = { role: 'model', parts: [{ text: "" }] };
      setChatHistory(prev => [...prev, modelMessage]);

      for await (const chunk of stream) {
        fullResponse += chunk.text;
        setChatHistory(prev => {
          const newHistory = [...prev];
          newHistory[newHistory.length - 1] = { role: 'model', parts: [{ text: fullResponse }] };
          return newHistory;
        });
      }
    } catch (e) {
      const errorMessage: ChatMessage = { role: 'model', parts: [{ text: "Sorry, I encountered an error. Please try again." }] };
      setChatHistory(prev => [...prev.slice(0, -1), errorMessage]);
    } finally {
      setIsChatting(false);
    }
  };

  const setChatInputAndSend = (text: string) => {
    setActiveTab('chat');
    setChatInput(text);
    setTimeout(() => {
        const sendButton = document.getElementById('send-chat-button');
        sendButton?.click();
    }, 100);
  };
  
  const handleFinalDownload = () => {
    if (!downloadableHtml || !analysisResult?.structuredData) return;
    const blob = new Blob([downloadableHtml], { type: 'text/html;charset=utf-8' });
    const filename = `${analysisResult.structuredData.name.replace(/\s/g, '_')}_Analysis.html`;
    window.saveAs(blob, filename);
  };

  const handleCreateGoogleDoc = () => {
    if (!analysisResult?.markdownReport) {
        alert("Report content is not available to copy.");
        return;
    }

    let fullMarkdown = analysisResult.markdownReport;

    if (analysisResult.sources && analysisResult.sources.length > 0) {
        fullMarkdown += `\n\n---\n\n## Web References Used in Analysis\n\n`;
        analysisResult.sources.forEach(source => {
            fullMarkdown += `*   [${source.title || source.uri}](${source.uri})\n`;
        });
    }
    
    navigator.clipboard.writeText(fullMarkdown).then(() => {
        window.open('https://docs.new', '_blank');
        setCopyStatus('copied_for_gdoc');
        setTimeout(() => setCopyStatus('idle'), 5000); // Show notification for 5 seconds
    }).catch(err => {
        console.error('Could not copy report text: ', err);
        alert('Failed to copy report. Your browser might not support this feature or has blocked it.');
    });
  };

  const renderTabButton = (tab: ResultTab, icon: React.ReactNode, text: string) => (
    <button
      onClick={() => setActiveTab(tab)}
      className={`flex items-center gap-2 px-4 py-2 rounded-md font-semibold transition-colors text-sm sm:text-base ${
        activeTab === tab 
          ? 'bg-blue-600 text-white shadow' 
          : 'bg-white text-gray-600 hover:bg-gray-100'
      }`}
    >
      {icon}
      <span>{text}</span>
    </button>
  );

  const renderInputScreen = () => (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gray-50 p-4">
      <div className="w-full max-w-2xl mx-auto bg-white rounded-2xl shadow-xl p-8">
        <div className="flex flex-col items-center text-center mb-8">
          <BrainCircuitIcon className="w-16 h-16 text-blue-600 mb-4" />
          <h1 className="text-4xl font-bold text-gray-800">AI Startup Analyzer</h1>
          <p className="mt-2 text-lg text-gray-500">
            Analyze a startup from our database or enter one manually.
          </p>
        </div>
        
        <div className="flex justify-center border-b mb-6">
            <button
                onClick={() => setInputMethod('database')}
                className={`px-6 py-3 font-semibold text-lg transition-colors ${inputMethod === 'database' ? 'text-blue-600 border-b-2 border-blue-600' : 'text-gray-500 hover:text-gray-700'}`}
            >
                From Database
            </button>
            <button
                onClick={() => setInputMethod('manual')}
                className={`px-6 py-3 font-semibold text-lg transition-colors ${inputMethod === 'manual' ? 'text-blue-600 border-b-2 border-blue-600' : 'text-gray-500 hover:text-gray-700'}`}
            >
                Manual Entry
            </button>
        </div>

        <div className="space-y-6">
            {inputMethod === 'database' && (
              <>
                {isLoadingCompanies ? (
                     <div className="flex items-center justify-center gap-3 text-lg font-semibold text-blue-600 h-28">
                        <div className="w-6 h-6 border-2 border-blue-500 border-t-transparent rounded-full animate-spin"></div>
                        <span>Loading companies from sheet...</span>
                    </div>
                ) : error && companies.length === 0 ? (
                    <div className="text-center text-red-600 bg-red-50 p-4 rounded-lg h-28 flex items-center justify-center">
                        <p>{error}</p>
                    </div>
                ) : (
                    <select
                      value={selectedCompanyId}
                      onChange={(e) => setSelectedCompanyId(e.target.value)}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-shadow bg-white text-lg"
                    >
                      <option value="" disabled>-- Select a Company --</option>
                      {companies.map((company) => (
                        <option key={company.name} value={company.name}>
                          {company.name}
                        </option>
                      ))}
                    </select>
                )}
              </>
            )}

            {inputMethod === 'manual' && (
                <div className="space-y-4">
                    <div>
                        <label htmlFor="company-name" className="block text-sm font-medium text-gray-700 mb-1">Company Name</label>
                        <input 
                            type="text" 
                            id="company-name"
                            value={manualCompanyName}
                            onChange={(e) => setManualCompanyName(e.target.value)}
                            placeholder="e.g., Acme Corporation"
                            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                        />
                    </div>
                    <div>
                        <label htmlFor="company-website" className="block text-sm font-medium text-gray-700 mb-1">Company Website</label>
                        <input 
                            type="text" 
                            id="company-website"
                            value={manualCompanyWebsite}
                            onChange={(e) => setManualCompanyWebsite(e.target.value)}
                            placeholder="e.g., acme.com"
                            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                        />
                    </div>
                     <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Pitch Deck (Optional)</label>
                        <FileUploader 
                            onFileSelect={setManualPitchDeck} 
                            acceptedFileTypes="application/pdf,.pptx,.docx,application/vnd.openxmlformats-officedocument.presentationml.presentation,application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                        />
                    </div>
                </div>
            )}

            <button
                onClick={handleStartAnalysis}
                disabled={
                    (inputMethod === 'database' && (isLoadingCompanies || !selectedCompanyId)) ||
                    (inputMethod === 'manual' && (!manualCompanyName || !manualCompanyWebsite))
                }
                className="w-full bg-blue-600 text-white font-bold py-3 px-4 rounded-lg hover:bg-blue-700 transition-transform transform hover:scale-105 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 flex items-center justify-center gap-2 disabled:bg-gray-400 disabled:transform-none disabled:cursor-not-allowed"
            >
                <SparklesIcon className="w-5 h-5" />
                <span>Start Analysis</span>
            </button>
        </div>
      </div>
    </div>
  );
  
  const renderErrorScreen = () => (
      <div className="flex flex-col items-center justify-center min-h-screen bg-red-50 p-4">
          <div className="w-full max-w-lg mx-auto bg-white rounded-2xl shadow-xl p-8 text-center">
              <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <XIcon className="w-8 h-8 text-red-600" />
              </div>
              <h2 className="text-2xl font-bold text-gray-800 mb-2">Analysis Failed</h2>
              <p className="text-gray-600 mb-6">
                  {error || 'An unexpected error occurred. Please try again.'}
              </p>
              <button
                  onClick={handleStartOver}
                  className="bg-blue-600 text-white font-bold py-2 px-6 rounded-lg hover:bg-blue-700 transition-colors"
              >
                  Start Over
              </button>
          </div>
      </div>
  );

  if (step === 'input') {
    if(error && companies.length === 0) {
        // Persist error on input screen only if company loading failed
    } else if (error) {
        setError(null);
    }
    return renderInputScreen();
  }
  
  if (step === 'error') {
    return renderErrorScreen();
  }

  if (step === 'analyzing') {
    const progress = parseInt(progressMessage, 10) || 0;
    
    let stageMessage = "Please wait while the AI generates your comprehensive report.";
    if (progress <= 10) {
        stageMessage = "Fetching and preparing the pitch deck for analysis...";
    }

    return (
        <div className="flex flex-col items-center justify-center min-h-screen bg-gray-50 p-4">
            <div className="w-full max-w-lg bg-white rounded-xl shadow-lg p-8 text-center">
                <BrainCircuitIcon className="w-16 h-16 text-blue-600 mb-4 mx-auto animate-pulse" />
                <h2 className="text-2xl font-bold text-gray-800 mb-2">Analyzing...</h2>
                <p className="text-gray-500 mb-6">
                    {stageMessage}
                </p>
                <div className="w-full bg-gray-200 rounded-full h-4 overflow-hidden">
                    <div
                        className="bg-blue-600 h-4 rounded-full transition-all duration-500 ease-out"
                        style={{ width: `${progress}%` }}
                    ></div>
                </div>
                <p className="mt-4 text-lg font-semibold text-blue-600">{progress}%</p>
            </div>
        </div>
    );
  }

  // Fallthrough to results screen
  if (!analysisResult) {
      // This state shouldn't normally be reached if logic is correct, but it's a good fallback.
      setError("Analysis complete but no data was found. Please try again.");
      return renderErrorScreen();
  }
  
  const { structuredData, pitchDeckSummary, sources } = analysisResult;

  if (!structuredData) {
      setError("Structured data could not be parsed. The AI response might be malformed.");
      return renderErrorScreen();
  }
  
  const AllInOneView = () => (
      <div id="all-content-wrapper" className="space-y-12">
          <section id="all-executive-summary" className="page-break-after">
              <ExecutiveSummary data={structuredData.executiveSummaryData} companyName={structuredData.name} onUpdate={handleDataChange} keywords={allKeywords} highlightEnabled={highlightEnabled} mermaidCode={structuredData.pictorial_technology_definition?.[0]?.value} />
          </section>
          <section id="all-data">
            <h2 className="text-3xl font-bold text-center mb-6 text-gray-800">Data & Charts</h2>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <div id="chart-indian-funding" className="bg-white p-4 rounded-lg shadow-sm border border-gray-200"><CompetitorChart data={structuredData.indian_competitor_chart_data} title="Funding Comparison (Indian)" /></div>
                <div id="chart-global-funding" className="bg-white p-4 rounded-lg shadow-sm border border-gray-200"><CompetitorChart data={structuredData.global_competitor_chart_data} title="Funding Comparison (Global)" /></div>
                <div id="chart-market-size" className="bg-white p-4 rounded-lg shadow-sm border border-gray-200"><CompetitorChart data={structuredData.market_size_chart_data} title="Market Size Projection (USD Billions)" /></div>
                <div id="chart-market-share" className="bg-white p-4 rounded-lg shadow-sm border border-gray-200"><CompetitorChart data={structuredData.market_subcategory_share_chart_data} title="Market Share by Subcategory (%)" /></div>
                <div id="chart-market-growth" className="bg-white p-4 rounded-lg shadow-sm border border-gray-200"><CompetitorChart data={structuredData.market_subcategory_growth_chart_data} title="Subcategory Growth (USD Billions)" /></div>
            </div>
            <div className="mt-12">
                 <MermaidDiagram code={structuredData.pictorial_technology_definition?.[0]?.value} title="Pictorial Technology Definition" />
            </div>
            <div className="mt-12">
                <h3 className="text-2xl font-bold text-center mb-6 text-gray-800">Indian Competitor Deep Dive</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                    {structuredData.indian_competitors.map((c, i) => <CompetitorCard key={`indian-${i}`} competitor={c} path={['structuredData', 'indian_competitors', i]} onUpdate={handleDataChange} keywords={allKeywords} highlightEnabled={highlightEnabled}/>)}
                </div>
            </div>
            <div className="mt-12">
                <h3 className="text-2xl font-bold text-center mb-6 text-gray-800">Global Competitor Deep Dive</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                    {structuredData.global_competitors.map((c, i) => <CompetitorCard key={`global-${i}`} competitor={c} path={['structuredData', 'global_competitors', i]} onUpdate={handleDataChange} keywords={allKeywords} highlightEnabled={highlightEnabled}/>)}
                </div>
            </div>
            <div className="mt-12">
                <FinancialProjectionsTable
                    projections={structuredData.financial_projections}
                    onUpdate={handleDataChange}
                    keywords={allKeywords}
                    highlightEnabled={highlightEnabled}
                />
            </div>
             <div className="mt-12">
                <h3 className="text-2xl font-bold text-center mb-6 text-gray-800">Founding Team</h3>
                <TeamDisplay founders={structuredData.executiveSummaryData.team?.founders} onUpdate={handleDataChange} keywords={allKeywords} highlightEnabled={highlightEnabled}/>
            </div>
          </section>
          <section id="all-resources" className="page-break-before">
            <Resources 
                news={structuredData.news_articles} 
                videos={structuredData.youtube_videos}
                papers={structuredData.research_papers}
                sources={sources}
                keywords={allKeywords}
                highlightEnabled={highlightEnabled}
            />
          </section>
          <section id="all-legal" className="page-break-before">
            <LegalAnalysis
                founderIssues={structuredData.executiveSummaryData.legal_analysis?.founder_legal_issues}
                companyIssues={structuredData.executiveSummaryData.legal_analysis?.company_legal_issues}
                onUpdate={handleDataChange}
                keywords={allKeywords}
                highlightEnabled={highlightEnabled}
            />
          </section>
          <div id="ic-note-live-content">
             <ICNote 
                  data={structuredData} 
                  onUpdate={handleDataChange} 
                  keywords={allKeywords} 
                  highlightEnabled={highlightEnabled} 
             />
          </div>
      </div>
  );

  const renderContent = () => {
    const commonProps = {
        data: structuredData,
        onUpdate: handleDataChange,
        keywords: allKeywords,
        highlightEnabled: highlightEnabled,
    };

      switch (activeTab) {
          case 'all':
              return <AllInOneView />;
          case 'executiveSummary':
              return <ExecutiveSummary 
                data={structuredData.executiveSummaryData} 
                companyName={structuredData.name} 
                onUpdate={handleDataChange} 
                keywords={allKeywords} 
                highlightEnabled={highlightEnabled}
                mermaidCode={structuredData.pictorial_technology_definition?.[0]?.value}
              />;
          case 'report':
              return <ICNote {...commonProps} />;
          case 'data':
              const marketCagrs = [
                  ...(structuredData.market_size_chart_data?.datasets || []),
                  ...(structuredData.market_subcategory_growth_chart_data?.datasets || [])
              ]
              .map(d => {
                  const match = d.label.match(/cagr\s*\(?([\d.]+)%\)?/i);
                  if (match && match[1]) {
                      return { label: d.label.split('(')[0].trim(), cagr: match[1] };
                  }
                  return null;
              })
              .filter((c, index, self) => c && self.findIndex(i => i?.label === c.label) === index);

              const subSectorCagrs = (structuredData.market_subcategory_growth_chart_data?.datasets || [])
                  .map(d => {
                      const match = d.label.match(/cagr\s*\(?([\d.]+)%\)?/i);
                      if (match && match[1]) {
                          return { label: d.label.split('(')[0].trim(), cagr: match[1] };
                      }
                      return null;
                  }).filter((c): c is { label: string; cagr: string; } => !!c);

              const allNews = structuredData.news_articles || [];
              const marketNews = allNews.filter(a => /market|growth|cagr|billion|valuation/i.test(a.title + a.summary)).slice(0, 4);
              
              const subSectorLabels = structuredData.market_subcategory_share_chart_data?.labels || [];
              const subSectorNews = allNews.filter(a => 
                  subSectorLabels.some(label => new RegExp(`\\b${label}\\b`, 'i').test(a.title + " " + a.summary))
              ).filter((item, index, self) => index === self.findIndex(t => t.url === item.url)) // unique
              .slice(0, 4);

              return (
                  <div className="space-y-12">
                      <h2 className="text-3xl font-bold text-center text-gray-800">Data & Charts</h2>
                      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                          <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-200"><CompetitorChart data={structuredData.indian_competitor_chart_data} title="Funding Comparison (Indian)" /></div>
                          <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-200"><CompetitorChart data={structuredData.global_competitor_chart_data} title="Funding Comparison (Global)" /></div>
                          <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-200"><CompetitorChart data={structuredData.market_size_chart_data} title="Market Size Projection (USD Billions)" /></div>
                          <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-200"><CompetitorChart data={structuredData.market_subcategory_share_chart_data} title="Market Share by Subcategory (%)" /></div>
                          <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-200"><CompetitorChart data={structuredData.market_subcategory_growth_chart_data} title="Subcategory Growth (USD Billions)" /></div>
                      </div>

                      <MermaidDiagram code={structuredData.pictorial_technology_definition?.[0]?.value} title="Pictorial Technology Definition" />

                      {/* Market Analysis Section */}
                      <div>
                          <h3 className="text-2xl font-bold text-center mb-6 text-gray-800">Market Analysis & Growth Drivers</h3>
                          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                              <div className="bg-white p-6 rounded-lg shadow-sm border">
                                  <h4 className="font-bold text-lg mb-3 text-gray-700">Market Fundamentals & Trends</h4>
                                  {marketCagrs.length > 0 && (
                                      <div className="mb-4">
                                          <h5 className="font-semibold text-gray-600 mb-2">Projected Growth Rates (CAGR):</h5>
                                          <ul className="list-disc pl-5 space-y-1 text-sm text-gray-800">
                                              {marketCagrs.map((item, i) => item && (
                                                  <li key={i}><strong>{item.label}:</strong> <span className="font-mono text-green-700 font-semibold">{item.cagr}%</span></li>
                                              ))}
                                          </ul>
                                      </div>
                                  )}
                                  {structuredData.fundingTrends && (
                                      <div>
                                          <h5 className="font-semibold text-gray-600 mb-2">Funding Insights:</h5>
                                          <p className="text-sm text-gray-800">{highlightText(structuredData.fundingTrends, allKeywords, highlightEnabled)}</p>
                                      </div>
                                  )}
                              </div>
                              <div className="bg-white p-6 rounded-lg shadow-sm border">
                                  <h4 className="font-bold text-lg mb-3 text-gray-700">Related Market News</h4>
                                  {marketNews.length > 0 ? (
                                      marketNews.map((article, i) => <NewsSnippetCard key={`market-news-${i}`} article={article} />)
                                  ) : (
                                      <p className="text-sm text-gray-500 italic">No specific market news found.</p>
                                  )}
                              </div>
                          </div>
                      </div>
                      
                      {/* Sub-sector Analysis Section */}
                      {subSectorLabels.length > 0 && subSectorCagrs.length > 0 && (
                          <div>
                              <h3 className="text-2xl font-bold text-center mb-6 text-gray-800">Sub-sector Analysis</h3>
                               <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                                  <div className="bg-white p-6 rounded-lg shadow-sm border">
                                      <h4 className="font-bold text-lg mb-3 text-gray-700">Sub-sector Growth Rates</h4>
                                      <ul className="list-disc pl-5 space-y-1 text-sm text-gray-800">
                                          {subSectorCagrs.map((item, i) => (
                                              <li key={`sub-cagr-${i}`}><strong>{item.label}:</strong> <span className="font-mono text-green-700 font-semibold">{item.cagr}%</span></li>
                                          ))}
                                      </ul>
                                  </div>
                                  <div className="bg-white p-6 rounded-lg shadow-sm border">
                                     <h4 className="font-bold text-lg mb-3 text-gray-700">Related Sub-sector News</h4>
                                      {subSectorNews.length > 0 ? (
                                          subSectorNews.map((article, i) => <NewsSnippetCard key={`sub-news-${i}`} article={article} />)
                                      ) : (
                                          <p className="text-sm text-gray-500 italic">No specific sub-sector news found.</p>
                                      )}
                                  </div>
                              </div>
                          </div>
                      )}

                        <div>
                           <FinancialProjectionsTable
                                projections={structuredData.financial_projections}
                                onUpdate={handleDataChange}
                                keywords={allKeywords}
                                highlightEnabled={highlightEnabled}
                            />
                        </div>

                      <div>
                          <h3 className="text-2xl font-bold text-center mb-6 text-gray-800">Indian Competitor Deep Dive</h3>
                          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                              {structuredData.indian_competitors.map((c, i) => <CompetitorCard key={`indian-${i}`} competitor={c} path={['structuredData', 'indian_competitors', i]} onUpdate={handleDataChange} keywords={allKeywords} highlightEnabled={highlightEnabled}/>)}
                          </div>
                      </div>
                      <div>
                          <h3 className="text-2xl font-bold text-center mb-6 text-gray-800">Global Competitor Deep Dive</h3>
                          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                              {structuredData.global_competitors.map((c, i) => <CompetitorCard key={`global-${i}`} competitor={c} path={['structuredData', 'global_competitors', i]} onUpdate={handleDataChange} keywords={allKeywords} highlightEnabled={highlightEnabled}/>)}
                          </div>
                      </div>
                      <div>
                          <h3 className="text-2xl font-bold text-center mb-6 text-gray-800">Founding Team</h3>
                          <TeamDisplay founders={structuredData.executiveSummaryData.team?.founders} onUpdate={handleDataChange} keywords={allKeywords} highlightEnabled={highlightEnabled}/>
                      </div>
                       <div>
                            <h3 className="text-2xl font-bold text-center mb-6 text-gray-800">Raw JSON Data</h3>
                            <textarea 
                                className="w-full h-96 font-mono text-xs p-4 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                                value={JSON.stringify(structuredData, null, 2)}
                                onChange={(e) => handleRawJsonChange(e.target.value)}
                            />
                            {rawJsonError && <p className="text-red-500 text-sm mt-2">{rawJsonError}</p>}
                        </div>
                  </div>
              );
          case 'resources':
              return <Resources 
                  news={structuredData.news_articles} 
                  videos={structuredData.youtube_videos}
                  papers={structuredData.research_papers}
                  sources={sources}
                  keywords={allKeywords}
                  highlightEnabled={highlightEnabled}
              />;
          case 'legal':
                return (
                    <LegalAnalysis
                        founderIssues={structuredData.executiveSummaryData.legal_analysis?.founder_legal_issues}
                        companyIssues={structuredData.executiveSummaryData.legal_analysis?.company_legal_issues}
                        onUpdate={handleDataChange}
                        keywords={allKeywords}
                        highlightEnabled={highlightEnabled}
                    />
                );
          case 'chat':
              return (
                  <div className="flex flex-col h-[80vh] bg-white rounded-lg shadow-lg border border-gray-200">
                      <div className="p-4 border-b">
                          <h2 className="text-xl font-bold text-gray-800">Chat with Analyst</h2>
                          {pitchDeckSummary && <p className="text-sm text-gray-500 mt-1">Pitch Deck Summary: {pitchDeckSummary}</p>}
                          <PromptSelector prompts={prompts} onSelect={setChatInputAndSend} disabled={isChatting} />
                      </div>
                      <div ref={chatContainerRef} className="flex-1 p-6 overflow-y-auto space-y-6">
                          {chatHistory.map((msg, index) => (
                              <div key={index} className={`flex items-end gap-3 ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                                  {msg.role === 'model' && <BrainCircuitIcon className="w-8 h-8 text-blue-500 flex-shrink-0" />}
                                  <div className={`p-4 rounded-lg chat-message-bubble ${msg.role}`}>
                                      <p className="whitespace-pre-wrap">{msg.parts[0].text}</p>
                                  </div>
                              </div>
                          ))}
                          {isChatting && chatHistory[chatHistory.length - 1]?.role !== 'model' && (
                              <div className="flex items-end gap-3 justify-start">
                                  <BrainCircuitIcon className="w-8 h-8 text-blue-500 flex-shrink-0" />
                                  <div className="p-4 rounded-lg chat-message-bubble model">
                                      <div className="flex items-center gap-2">
                                          <div className="w-2 h-2 bg-blue-400 rounded-full animate-pulse"></div>
                                          <div className="w-2 h-2 bg-blue-400 rounded-full animate-pulse [animation-delay:0.2s]"></div>
                                          <div className="w-2 h-2 bg-blue-400 rounded-full animate-pulse [animation-delay:0.4s]"></div>
                                      </div>
                                  </div>
                              </div>
                          )}
                      </div>
                      <div className="p-4 border-t bg-gray-50">
                          <div className="flex items-center gap-4">
                              <input
                                  type="text"
                                  value={chatInput}
                                  onChange={(e) => setChatInput(e.target.value)}
                                  onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                                  placeholder="Ask a follow-up question..."
                                  className="flex-1 px-4 py-2 border rounded-full focus:ring-2 focus:ring-blue-500"
                                  disabled={isChatting}
                              />
                              <button
                                  id="send-chat-button"
                                  onClick={handleSendMessage}
                                  disabled={!chatInput.trim() || isChatting}
                                  className="p-3 bg-blue-600 text-white rounded-full hover:bg-blue-700 disabled:bg-gray-300 transition-colors"
                              >
                                  <PaperAirplaneIcon className="w-5 h-5" />
                              </button>
                          </div>
                      </div>
                  </div>
              );
          case 'download':
                return (
                    <>
                        {/* Render the 'all' view hidden to make its DOM available for cloning */}
                        <div style={{ display: 'none' }}>
                            <AllInOneView />
                        </div>
                        <div className="text-center bg-white p-8 rounded-lg shadow-lg border">
                            <h2 className="text-3xl font-bold mb-4 text-gray-800">Download Report</h2>
                            <p className="text-gray-600 mb-6 max-w-2xl mx-auto">
                                A self-contained, editable HTML file of the 'All-in-One' view has been generated. You can save it locally for offline access, editing, and sharing.
                            </p>
                            {isGeneratingDownload ? (
                                <div className="flex items-center justify-center gap-3 text-lg font-semibold text-blue-600 h-20">
                                    <div className="w-6 h-6 border-2 border-blue-500 border-t-transparent rounded-full animate-spin"></div>
                                    <span>Generating your file...</span>
                                </div>
                            ) : downloadableHtml ? (
                                <div className="space-y-4">
                                     <button 
                                        onClick={handleFinalDownload}
                                        className="inline-flex items-center gap-2 bg-green-600 text-white font-bold py-3 px-6 rounded-lg hover:bg-green-700 transition-transform transform hover:scale-105"
                                    >
                                        <DownloadIcon className="w-5 h-5" />
                                        Download Editable HTML
                                    </button>
                                     <div className="mt-6 border-t pt-6">
                                        <p className="text-gray-600 mb-4 max-w-2xl mx-auto">Alternatively, copy the full markdown report to your clipboard and paste it into a new Google Doc.</p>
                                        <button 
                                            onClick={handleCreateGoogleDoc}
                                            className="inline-flex items-center gap-2 bg-blue-500 text-white font-bold py-3 px-6 rounded-lg hover:bg-blue-600 transition-colors"
                                        >
                                           {copyStatus === 'copied_for_gdoc' ? <ClipboardDocumentCheckIcon className="w-5 h-5" /> : <DocumentDuplicateIcon className="w-5 h-5" />}
                                            <span>{copyStatus === 'copied_for_gdoc' ? 'Copied! Opening Google Docs...' : 'Copy for Google Docs'}</span>
                                        </button>
                                     </div>
                                </div>
                            ) : (
                                <p className="text-red-500">Could not generate the download file.</p>
                            )}
                        </div>
                    </>
                );
          default:
              return null;
      }
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <header className="bg-white shadow-sm sticky top-0 z-20 no-print">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex flex-col sm:flex-row justify-between items-center">
            <div className="flex items-center gap-3 mb-4 sm:mb-0">
                <BrainCircuitIcon className="w-8 h-8 text-blue-600" />
                <h1 className="text-xl font-bold text-gray-800 truncate">
                    AI Analysis: <span className="font-normal">{structuredData.name}</span>
                </h1>
            </div>
            <div className="flex items-center gap-4">
                <div className="flex items-center gap-2">
                    <LightBulbIcon className="w-5 h-5 text-yellow-500" />
                    <span className="text-sm font-medium text-gray-600">Keyword Highlighting</span>
                     <label htmlFor="highlight-toggle" className="inline-flex relative items-center cursor-pointer">
                        <input type="checkbox" checked={highlightEnabled} onChange={() => setHighlightEnabled(!highlightEnabled)} id="highlight-toggle" className="sr-only peer" />
                        <div className="w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-2 peer-focus:ring-blue-300 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-0.5 after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                    </label>
                </div>
                 <button 
                    onClick={handleStartOver}
                    className="text-sm font-semibold text-blue-600 hover:text-blue-800"
                >
                    Start Over
                </button>
            </div>
        </div>
        <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-4">
            <div className="flex flex-wrap items-center justify-center gap-2">
                {renderTabButton('all', <ClipboardDocumentListIcon className="w-5 h-5" />, 'All-in-One')}
                {renderTabButton('executiveSummary', <SparklesIcon className="w-5 h-5" />, 'Executive Summary')}
                {renderTabButton('report', <BookOpenIcon className="w-5 h-5" />, 'IC Note (Report)')}
                {renderTabButton('data', <TableCellsIcon className="w-5 h-5" />, 'Data & Charts')}
                {renderTabButton('resources', <BuildingOfficeIcon className="w-5 h-5" />, 'Resources')}
                {renderTabButton('legal', <ScaleIcon className="w-5 h-5" />, 'Legal')}
                {renderTabButton('chat', <PencilSquareIcon className="w-5 h-5" />, 'Chat with Analyst')}
                {renderTabButton('download', <DownloadIcon className="w-5 h-5" />, 'Download')}
            </div>
        </nav>
      </header>
      <main className="max-w-7xl mx-auto p-4 sm:p-6 lg:p-8">
        {renderContent()}
      </main>
    </div>
  );
}