import React, { useRef, useState, useEffect } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { OrbitControls, Stage, useTexture, Center, Environment, ContactShadows } from '@react-three/drei';
import * as THREE from 'three';

interface ModelViewerProps {
  textureUrl: string | null;
  displacementUrl: string | null;
  alphaUrl: string | null;
  modelType: 'sphere' | 'cube' | 'torus' | 'plane' | 'custom' | 'product';
}

function TexturedMesh({ textureUrl, displacementUrl, alphaUrl, modelType }: ModelViewerProps) {
  const meshRef = useRef<THREE.Mesh>(null);
  const [texture, setTexture] = useState<THREE.Texture | null>(null);
  const [displacement, setDisplacement] = useState<THREE.Texture | null>(null);
  const [alpha, setAlpha] = useState<THREE.Texture | null>(null);

  useEffect(() => {
    const loader = new THREE.TextureLoader();
    if (textureUrl) {
      loader.load(textureUrl, (tex) => {
        tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
        setTexture(tex);
      });
    } else {
      setTexture(null);
    }

    if (displacementUrl) {
      loader.load(displacementUrl, (tex) => {
        tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
        setDisplacement(tex);
      });
    } else {
      setDisplacement(null);
    }

    if (alphaUrl) {
      loader.load(alphaUrl, (tex) => {
        tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
        setAlpha(tex);
      });
    } else {
      setAlpha(null);
    }
  }, [textureUrl, displacementUrl, alphaUrl]);

  useFrame((state) => {
    if (meshRef.current && modelType !== 'product') {
      meshRef.current.rotation.y += 0.005;
    }
  });

  const getGeometry = () => {
    switch (modelType) {
      case 'sphere': return <sphereGeometry args={[1, 256, 256]} />;
      case 'cube': return <boxGeometry args={[1.5, 1.5, 1.5, 128, 128, 128]} />;
      case 'torus': return <torusGeometry args={[0.8, 0.3, 128, 256]} />;
      case 'plane': 
      case 'custom':
      case 'product':
        return <planeGeometry args={[2.5, 2.5, 1024, 1024]} />;
      default: return <sphereGeometry args={[1, 128, 128]} />;
    }
  };

  return (
    <mesh ref={meshRef} rotation={modelType === 'custom' || modelType === 'product' ? [-Math.PI / 12, 0, 0] : [0, 0, 0]}>
      {getGeometry()}
      <meshStandardMaterial 
        map={texture} 
        displacementMap={displacement}
        displacementScale={displacement ? (modelType === 'product' ? 1.2 : 0.6) : 0}
        displacementBias={-0.1}
        alphaMap={alpha}
        transparent={!!alpha}
        alphaTest={0.5}
        color={texture ? 'white' : '#444'} 
        roughness={0.3}
        metalness={0.4}
        envMapIntensity={1.5}
        side={THREE.DoubleSide}
      />
    </mesh>
  );
}

export default function ModelViewer({ textureUrl, displacementUrl, alphaUrl, modelType }: ModelViewerProps) {
  return (
    <div className="w-full h-full bg-zinc-950 rounded-2xl overflow-hidden border border-white/10 shadow-2xl">
      <Canvas shadows camera={{ position: [0, 0, 4], fov: 45 }}>
        <ambientLight intensity={0.8} />
        <directionalLight position={[5, 10, 5]} intensity={1.5} castShadow />
        <pointLight position={[-5, 5, -5]} intensity={0.8} />
        
        <React.Suspense fallback={null}>
          <Stage environment="studio" intensity={0.8}>
            <Center>
              <TexturedMesh 
                textureUrl={textureUrl} 
                displacementUrl={displacementUrl} 
                alphaUrl={alphaUrl}
                modelType={modelType} 
              />
            </Center>
          </Stage>
        </React.Suspense>
        
        <OrbitControls makeDefault minPolarAngle={0} maxPolarAngle={Math.PI} />
        <Environment preset="studio" />
        <ContactShadows position={[0, -1.5, 0]} opacity={0.6} scale={10} blur={2.5} far={4.5} />
      </Canvas>
    </div>
  );
}
