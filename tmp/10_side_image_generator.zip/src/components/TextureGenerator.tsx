import React, { useState, useRef } from 'react';
import { GoogleGenAI } from "@google/genai";
import { Loader2, Sparkles, Image as ImageIcon, Wand2, RefreshCw, Upload, X, Maximize2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface TextureGeneratorProps {
  onTextureGenerated: (url: string, displacementUrl?: string | null, alphaUrl?: string | null) => void;
}

export default function TextureGenerator({ onTextureGenerated }: TextureGeneratorProps) {
  const [prompt, setPrompt] = useState('');
  const [quality, setQuality] = useState<'standard' | 'high' | 'ultra'>('high');
  const [style, setStyle] = useState<'realistic' | 'stylized' | 'sci-fi' | 'organic'>('realistic');
  const [isGenerating, setIsGenerating] = useState(false);
  const [isConverting, setIsConverting] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [isGeneratingAngles, setIsGeneratingAngles] = useState(false);
  const [shapeAnalysis, setShapeAnalysis] = useState<string | null>(null);
  const [multiAngleImages, setMultiAngleImages] = useState<string[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [history, setHistory] = useState<string[]>([]);
  const [referenceImage, setReferenceImage] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setReferenceImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const analyzeAndGenerate3D = async () => {
    if (!referenceImage) return;
    setIsAnalyzing(true);
    setIsConverting(true);
    setError(null);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      const base64Data = referenceImage.split(',')[1];
      
      // Step 1: Shape Analysis & Background Removal Instruction
      const analysisResponse = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: {
          parts: [
            {
              inlineData: {
                data: base64Data,
                mimeType: "image/png",
              },
            },
            {
              text: "Analyze the 3D geometry and shape of the product in this image. Describe its primary volumes, surface curvature, and structural details. Also, confirm if the background can be cleanly removed.",
            },
          ],
        },
      });
      
      setShapeAnalysis(analysisResponse.text || "Analysis complete.");

      // Step 2: Generate Depth, Alpha, and Background-Removed Texture
      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash-image',
        contents: {
          parts: [
            {
              inlineData: {
                data: base64Data,
                mimeType: "image/png",
              },
            },
            {
              text: `Based on the shape analysis, generate:
              1. A high-precision depth map (grayscale).
              2. A clean alpha mask (binary).
              3. A version of the product with the background COMPLETELY removed (replaced with pure black #000000).
              Return the background-removed version as the primary image part.`,
            },
          ],
        },
        config: {
          imageConfig: {
            aspectRatio: "1:1",
          },
        },
      });

      let resultUrl = '';
      const parts = response.candidates?.[0]?.content?.parts;
      if (parts) {
        for (const part of parts) {
          if (part.inlineData) {
            resultUrl = `data:image/png;base64,${part.inlineData.data}`;
            break;
          }
        }
      }

      if (resultUrl) {
        onTextureGenerated(resultUrl, resultUrl, resultUrl);
      } else {
        throw new Error('Failed to generate 3D maps.');
      }
    } catch (err: any) {
      setError('Failed to process product. ' + err.message);
    } finally {
      setIsAnalyzing(false);
      setIsConverting(false);
    }
  };

  const generateMultiAngles = async () => {
    if (!referenceImage) return;
    setIsGeneratingAngles(true);
    setError(null);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      const base64Data = referenceImage.split(',')[1];
      
      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash-image',
        contents: {
          parts: [
            {
              inlineData: {
                data: base64Data,
                mimeType: "image/png",
              },
            },
            {
              text: "Generate a grid of 10 different viewing angles of this exact product. Include front, back, sides, top, bottom, and 4 isometric perspectives. Keep the product consistent in every frame. The background must be pure white for all angles.",
            },
          ],
        },
        config: {
          imageConfig: {
            aspectRatio: "1:1",
          },
        },
      });

      const parts = response.candidates?.[0]?.content?.parts;
      if (parts) {
        for (const part of parts) {
          if (part.inlineData) {
            setMultiAngleImages([`data:image/png;base64,${part.inlineData.data}`]);
            break;
          }
        }
      }
    } catch (err: any) {
      setError('Failed to generate angles. ' + err.message);
    } finally {
      setIsGeneratingAngles(false);
    }
  };

  const generateTexture = async () => {
    if (!prompt.trim() && !referenceImage) return;
    
    setIsGenerating(true);
    setError(null);
    
    const qualityPrompt = {
      standard: "standard quality",
      high: "high-definition, 4K resolution, professional grade",
      ultra: "ultra-realistic, 8K resolution, cinematic detail, masterwork quality, intricate micro-textures"
    }[quality];

    const stylePrompt = {
      realistic: "photorealistic, natural lighting, physically accurate materials",
      stylized: "artistic, hand-painted style, vibrant colors, clean shapes",
      'sci-fi': "futuristic, high-tech, metallic, glowing elements, industrial",
      organic: "natural, biological, earthy tones, complex cellular patterns"
    }[style];

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      
      const contents: any = {
        parts: [
          {
            text: `Generate a ${qualityPrompt} seamless 3D texture. 
            Style: ${stylePrompt}. 
            Subject: ${prompt}. 
            ${referenceImage ? 'Strictly follow the style, pattern, and color palette of the provided reference image.' : ''} 
            The texture must be perfectly tileable, with no visible seams, and include fine surface details suitable for high-end 3D rendering.`,
          },
        ],
      };

      if (referenceImage) {
        const base64Data = referenceImage.split(',')[1];
        contents.parts.push({
          inlineData: {
            data: base64Data,
            mimeType: "image/png",
          },
        });
      }

      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash-image',
        contents: contents,
        config: {
          imageConfig: {
            aspectRatio: "1:1",
          },
        },
      });

      let imageUrl = '';
      const parts = response.candidates?.[0]?.content?.parts;
      if (parts) {
        for (const part of parts) {
          if (part.inlineData) {
            const base64EncodeString = part.inlineData.data;
            imageUrl = `data:image/png;base64,${base64EncodeString}`;
            break;
          }
        }
      }

      if (imageUrl) {
        onTextureGenerated(imageUrl);
        setHistory(prev => [imageUrl, ...prev.slice(0, 4)]);
      } else {
        const textError = response.candidates?.[0]?.content?.parts?.find(p => p.text)?.text;
        throw new Error(textError || 'No image was generated. The model might have filtered the output.');
      }
    } catch (err: any) {
      console.error('Generation error:', err);
      setError(err.message || 'Failed to generate texture. Please check your API key and try again.');
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="flex flex-col gap-6 p-6 bg-zinc-900/50 rounded-2xl border border-white/5 backdrop-blur-xl">
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-emerald-400" />
          <h2 className="text-lg font-semibold text-white">AI Texture Generator</h2>
        </div>
        <button 
          onClick={() => {
            setPrompt('');
            setReferenceImage(null);
            setError(null);
          }}
          className="p-2 hover:bg-white/5 rounded-lg transition-colors text-zinc-500 hover:text-white"
          title="Reset"
        >
          <RefreshCw className="w-4 h-4" />
        </button>
      </div>

      <div className="space-y-4">
        {/* Reference Image Upload */}
        <div className="relative">
          {referenceImage ? (
            <div className="relative w-full aspect-video rounded-xl overflow-hidden border border-emerald-500/30 group">
              <img src={referenceImage} alt="Reference" className="w-full h-full object-cover opacity-50" />
              <div className="absolute inset-0 flex items-center justify-center bg-black/40">
                <span className="text-xs font-medium text-emerald-400 flex items-center gap-2">
                  <ImageIcon className="w-4 h-4" />
                  Style Reference Active
                </span>
              </div>
              <button 
                onClick={() => setReferenceImage(null)}
                className="absolute top-2 right-2 p-1.5 bg-black/60 hover:bg-red-500/80 text-white rounded-lg transition-all opacity-0 group-hover:opacity-100"
              >
                <X className="w-4 h-4" />
              </button>
              <div className="absolute bottom-2 left-2 right-2 flex flex-col gap-2 opacity-0 group-hover:opacity-100 transition-all">
                <div className="flex gap-2">
                  <button
                    onClick={analyzeAndGenerate3D}
                    disabled={isConverting || isAnalyzing}
                    className="flex-1 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-[10px] font-bold uppercase tracking-wider rounded-lg flex items-center justify-center gap-2"
                  >
                    {isAnalyzing ? <Loader2 className="w-3 h-3 animate-spin" /> : <Maximize2 className="w-3 h-3" />}
                    Analyze & 3D Gen
                  </button>
                  <button
                    onClick={generateMultiAngles}
                    disabled={isGeneratingAngles}
                    className="flex-1 py-2 bg-zinc-800 hover:bg-zinc-700 text-white text-[10px] font-bold uppercase tracking-wider rounded-lg flex items-center justify-center gap-2"
                  >
                    {isGeneratingAngles ? <Loader2 className="w-3 h-3 animate-spin" /> : <RefreshCw className="w-3 h-3" />}
                    10-Angle View
                  </button>
                </div>
              </div>
            </div>
          ) : (
            <button
              onClick={() => fileInputRef.current?.click()}
              className="w-full py-4 border-2 border-dashed border-white/5 hover:border-emerald-500/30 hover:bg-emerald-500/5 rounded-xl transition-all flex flex-col items-center gap-2 text-zinc-500 hover:text-emerald-400"
            >
              <Upload className="w-5 h-5" />
              <span className="text-xs font-medium">Upload Style Reference (Optional)</span>
            </button>
          )}
          <input 
            type="file" 
            ref={fileInputRef} 
            onChange={handleImageUpload} 
            accept="image/*" 
            className="hidden" 
          />
        </div>

        <div className="relative group">
          <textarea
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="Describe your texture (e.g., 'cracked magma rock', 'brushed futuristic metal')..."
            className="w-full h-24 px-4 py-3 bg-zinc-950 border border-white/10 rounded-xl text-zinc-200 placeholder:text-zinc-600 focus:outline-none focus:ring-2 focus:ring-emerald-500/50 focus:border-emerald-500/50 transition-all resize-none"
          />
          
          <div className="grid grid-cols-2 gap-2 mt-2">
            <div className="space-y-1">
              <label className="text-[10px] font-bold text-zinc-600 uppercase tracking-wider ml-1">Quality</label>
              <select 
                value={quality}
                onChange={(e) => setQuality(e.target.value as any)}
                className="w-full bg-zinc-950 border border-white/10 rounded-lg px-2 py-1.5 text-xs text-zinc-300 focus:outline-none focus:border-emerald-500/50"
              >
                <option value="standard">Standard</option>
                <option value="high">High Detail</option>
                <option value="ultra">Ultra Precision</option>
              </select>
            </div>
            <div className="space-y-1">
              <label className="text-[10px] font-bold text-zinc-600 uppercase tracking-wider ml-1">Style</label>
              <select 
                value={style}
                onChange={(e) => setStyle(e.target.value as any)}
                className="w-full bg-zinc-950 border border-white/10 rounded-lg px-2 py-1.5 text-xs text-zinc-300 focus:outline-none focus:border-emerald-500/50"
              >
                <option value="realistic">Realistic</option>
                <option value="stylized">Stylized</option>
                <option value="sci-fi">Sci-Fi</option>
                <option value="organic">Organic</option>
              </select>
            </div>
          </div>

          <div className="flex justify-end mt-4">
            <button
              onClick={generateTexture}
              disabled={isGenerating || (!prompt.trim() && !referenceImage)}
              className="flex items-center gap-2 px-6 py-2.5 bg-emerald-600 hover:bg-emerald-500 disabled:bg-zinc-800 disabled:text-zinc-600 text-white font-bold rounded-xl transition-all shadow-lg shadow-emerald-900/20"
            >
              {isGenerating ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  Generating...
                </>
              ) : (
                <>
                  <Wand2 className="w-4 h-4" />
                  Generate Texture
                </>
              )}
            </button>
          </div>
        </div>
      </div>

      {shapeAnalysis && (
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="p-4 bg-emerald-500/5 border border-emerald-500/10 rounded-xl"
        >
          <h3 className="text-[10px] font-bold text-emerald-400 uppercase tracking-widest mb-2">Shape Analysis</h3>
          <p className="text-xs text-zinc-400 leading-relaxed italic">"{shapeAnalysis}"</p>
        </motion.div>
      )}

      {multiAngleImages.length > 0 && (
        <div className="space-y-3">
          <h3 className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest">Multi-Angle Reference</h3>
          <div className="rounded-xl overflow-hidden border border-white/10">
            <img src={multiAngleImages[0]} alt="Multi-angle grid" className="w-full h-auto" />
          </div>
          <p className="text-[10px] text-zinc-600 text-center italic">Generated 10 consistent viewing angles for 3D reconstruction</p>
        </div>
      )}

      {error && (
        <motion.div 
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="p-3 bg-red-500/10 border border-red-500/20 rounded-lg text-red-400 text-sm"
        >
          {error}
        </motion.div>
      )}

      {history.length > 0 && (
        <div className="flex flex-col gap-3">
          <span className="text-xs font-medium text-zinc-500 uppercase tracking-wider">Recent Textures</span>
          <div className="grid grid-cols-5 gap-2">
            {history.map((url, idx) => (
              <button
                key={idx}
                onClick={() => onTextureGenerated(url)}
                className="aspect-square rounded-lg overflow-hidden border border-white/10 hover:border-emerald-500/50 transition-all"
              >
                <img src={url} alt="History" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

