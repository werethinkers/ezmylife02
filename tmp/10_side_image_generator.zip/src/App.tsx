import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Box, 
  Circle, 
  Torus as TorusIcon, 
  Square, 
  Settings, 
  Layers, 
  Maximize2, 
  Download,
  Info,
  Cpu,
  Cuboid
} from 'lucide-react';
import ModelViewer from './components/ModelViewer';
import TextureGenerator from './components/TextureGenerator';

type ModelType = 'sphere' | 'cube' | 'torus' | 'plane' | 'custom' | 'product';

export default function App() {
  const [textureUrl, setTextureUrl] = useState<string | null>(null);
  const [displacementUrl, setDisplacementUrl] = useState<string | null>(null);
  const [alphaUrl, setAlphaUrl] = useState<string | null>(null);
  const [modelType, setModelType] = useState<ModelType>('sphere');
  const [activeTab, setActiveTab] = useState<'generate' | 'settings'>('generate');

  const models = [
    { id: 'sphere', icon: Circle, label: 'Sphere' },
    { id: 'cube', icon: Box, label: 'Cube' },
    { id: 'torus', icon: TorusIcon, label: 'Torus' },
    { id: 'plane', icon: Square, label: 'Plane' },
    { id: 'product', icon: Cuboid, label: 'Product' },
  ];

  const handleTextureGenerated = (url: string, dispUrl?: string | null, aUrl?: string | null) => {
    setTextureUrl(url);
    if (dispUrl) {
      setDisplacementUrl(dispUrl);
      setAlphaUrl(aUrl || null);
      setModelType('product');
    } else {
      setDisplacementUrl(null);
      setAlphaUrl(null);
    }
  };

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-zinc-400 font-sans selection:bg-emerald-500/30">
      {/* Header */}
      <header className="h-16 border-bottom border-white/5 flex items-center justify-between px-6 bg-zinc-900/50 backdrop-blur-md sticky top-0 z-50">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-emerald-600 rounded-lg flex items-center justify-center shadow-lg shadow-emerald-900/20">
            <Cpu className="w-5 h-5 text-white" />
          </div>
          <h1 className="text-white font-bold tracking-tight text-lg">StableGen <span className="text-emerald-500 font-mono text-sm ml-1">v1.3</span></h1>
        </div>
        
        <div className="flex items-center gap-4">
          <button className="p-2 hover:bg-white/5 rounded-lg transition-colors">
            <Info className="w-5 h-5" />
          </button>
          <button className="flex items-center gap-2 px-4 py-1.5 bg-white/5 hover:bg-white/10 text-white text-sm font-medium rounded-lg border border-white/10 transition-all">
            <Download className="w-4 h-4" />
            Export
          </button>
        </div>
      </header>

      <main className="flex h-[calc(100vh-64px)] overflow-hidden">
        {/* Sidebar */}
        <aside className="w-96 border-right border-white/5 bg-zinc-900/30 flex flex-col">
          <div className="flex border-bottom border-white/5">
            <button 
              onClick={() => setActiveTab('generate')}
              className={`flex-1 py-4 text-sm font-medium transition-all relative ${activeTab === 'generate' ? 'text-white' : 'hover:text-zinc-200'}`}
            >
              <div className="flex items-center justify-center gap-2">
                <Layers className="w-4 h-4" />
                Generate
              </div>
              {activeTab === 'generate' && <motion.div layoutId="tab" className="absolute bottom-0 left-0 right-0 h-0.5 bg-emerald-500" />}
            </button>
            <button 
              onClick={() => setActiveTab('settings')}
              className={`flex-1 py-4 text-sm font-medium transition-all relative ${activeTab === 'settings' ? 'text-white' : 'hover:text-zinc-200'}`}
            >
              <div className="flex items-center justify-center gap-2">
                <Settings className="w-4 h-4" />
                Settings
              </div>
              {activeTab === 'settings' && <motion.div layoutId="tab" className="absolute bottom-0 left-0 right-0 h-0.5 bg-emerald-500" />}
            </button>
          </div>

          <div className="flex-1 overflow-y-auto p-6 space-y-8 custom-scrollbar">
            <AnimatePresence mode="wait">
              {activeTab === 'generate' ? (
                <motion.div
                  key="generate"
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="space-y-8"
                >
                  <section>
                    <label className="text-xs font-bold text-zinc-500 uppercase tracking-widest mb-4 block">View Mode</label>
                    <div className="grid grid-cols-5 gap-2">
                      {models.map((m) => (
                        <button
                          key={m.id}
                          onClick={() => setModelType(m.id as ModelType)}
                          className={`flex flex-col items-center gap-2 p-3 rounded-xl border transition-all ${
                            modelType === m.id 
                            ? 'bg-emerald-500/10 border-emerald-500/50 text-emerald-400' 
                            : 'bg-zinc-950 border-white/5 hover:border-white/10 text-zinc-500'
                          }`}
                        >
                          <m.icon className="w-5 h-5" />
                          <span className="text-[8px] font-medium text-center">{m.label}</span>
                        </button>
                      ))}
                    </div>
                  </section>

                  <TextureGenerator onTextureGenerated={handleTextureGenerated} />
                </motion.div>
              ) : (
                <motion.div
                  key="settings"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 20 }}
                  className="space-y-6"
                >
                  <div className="p-4 bg-zinc-950 border border-white/5 rounded-xl">
                    <h3 className="text-white text-sm font-medium mb-2">Environment Map</h3>
                    <p className="text-xs text-zinc-500 mb-4">Select the lighting environment for the preview stage.</p>
                    <select className="w-full bg-zinc-900 border border-white/10 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:ring-1 focus:ring-emerald-500">
                      <option>Studio</option>
                      <option>City</option>
                      <option>Sunset</option>
                      <option>Warehouse</option>
                    </select>
                  </div>
                  
                  <div className="p-4 bg-zinc-950 border border-white/5 rounded-xl">
                    <h3 className="text-white text-sm font-medium mb-2">Rendering Quality</h3>
                    <input type="range" className="w-full accent-emerald-500" />
                    <div className="flex justify-between text-[10px] text-zinc-600 mt-1">
                      <span>Performance</span>
                      <span>Quality</span>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          <div className="p-4 border-top border-white/5 bg-zinc-950/50">
            <div className="flex items-center justify-between text-[10px] font-mono text-zinc-600">
              <span>GPU ACCELERATION: ON</span>
              <span>READY</span>
            </div>
          </div>
        </aside>

        {/* Main Viewer */}
        <section className="flex-1 relative bg-[#050505]">
          <div className="absolute inset-0 p-6">
            <ModelViewer 
              textureUrl={textureUrl} 
              displacementUrl={displacementUrl} 
              alphaUrl={alphaUrl}
              modelType={modelType} 
            />
          </div>
          
          {/* Floating Controls */}
          <div className="absolute bottom-10 left-1/2 -translate-x-1/2 flex items-center gap-2 p-1.5 bg-zinc-900/80 backdrop-blur-xl border border-white/10 rounded-2xl shadow-2xl">
            <button className="p-3 hover:bg-white/5 rounded-xl transition-colors text-white">
              <Maximize2 className="w-5 h-5" />
            </button>
            <div className="w-px h-6 bg-white/10 mx-1" />
            <div className="px-4 py-2 text-xs font-medium text-zinc-400">
              {modelType.toUpperCase()} VIEW
            </div>
          </div>
        </section>
      </main>

      <style dangerouslySetInnerHTML={{ __html: `
        .custom-scrollbar::-webkit-scrollbar {
          width: 4px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: transparent;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: rgba(255, 255, 255, 0.1);
          border-radius: 10px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background: rgba(255, 255, 255, 0.2);
        }
      `}} />
    </div>
  );
}


